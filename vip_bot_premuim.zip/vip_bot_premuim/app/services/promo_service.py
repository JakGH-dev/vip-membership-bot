from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.promo import PromoCode
from app.database.repositories.promo_repo import PromoRepository
from app.utils.datetime_utils import utcnow


class PromoApplicationError(Exception):
    pass


class PromoService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.promo_repo = PromoRepository(session)

    async def validate_and_get(
        self, code: str, plan_id: int, user_id: int
    ) -> PromoCode:
        promo = await self.promo_repo.get_by_code(code)
        if promo is None:
            raise PromoApplicationError("Promo code not found")

        if not promo.is_active:
            raise PromoApplicationError("Promo code is not active")

        now = utcnow()
        if not promo.is_within_validity(now):
            raise PromoApplicationError("Promo code is expired or not yet valid")

        if not promo.applies_to_plan(plan_id):
            raise PromoApplicationError("Promo code does not apply to this plan")

        if not promo.has_remaining_total_uses():
            raise PromoApplicationError("Promo code has reached its usage limit")

        user_usages = await self.promo_repo.count_user_usages(promo.id, user_id)
        if user_usages >= promo.max_uses_per_user:
            raise PromoApplicationError("You have already used this promo code")

        return promo
