from __future__ import annotations

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging_config import get_logger
from app.config.settings import Settings
from app.database.models.subscription import Subscription
from app.database.models.user import User
from app.database.repositories.subscription_repo import SubscriptionRepository
from app.utils.datetime_utils import utcnow

logger = get_logger(__name__)


class VipChannelService:
    """Wraps all interactions with the private VIP Telegram channel/group."""

    def __init__(self, session: AsyncSession, bot: Bot, settings: Settings) -> None:
        self.session = session
        self.bot = bot
        self.settings = settings
        self.subscription_repo = SubscriptionRepository(session)

    async def create_invite_link(self, subscription: Subscription) -> str:
        expire_date = utcnow().timestamp() + self.settings.vip_invite_link_expire_seconds
        invite = await self.bot.create_chat_invite_link(
            chat_id=self.settings.vip_channel_id,
            expire_date=int(expire_date),
            member_limit=self.settings.vip_invite_link_member_limit,
            creates_join_request=False,
            name=f"vip-sub-{subscription.id}",
        )
        await self.subscription_repo.set_invite_link(subscription, invite.invite_link)
        logger.info(
            "vip_invite_link_created",
            subscription_id=subscription.id,
            user_id=subscription.user_id,
        )
        return invite.invite_link

    async def get_or_create_invite_link(self, subscription: Subscription) -> str:
        if subscription.vip_invite_link:
            return subscription.vip_invite_link
        return await self.create_invite_link(subscription)

    async def remove_user_from_channel(self, user: User) -> bool:
        """Bans then immediately unbans the user, which removes them from
        the channel/group without leaving them permanently blocked - so a
        future renewal can let them rejoin via a fresh invite link."""
        try:
            await self.bot.ban_chat_member(
                chat_id=self.settings.vip_channel_id, user_id=user.telegram_id
            )
            await self.bot.unban_chat_member(
                chat_id=self.settings.vip_channel_id,
                user_id=user.telegram_id,
                only_if_banned=True,
            )
            logger.info(
                "vip_member_removed", user_id=user.id, telegram_id=user.telegram_id
            )
            return True
        except TelegramForbiddenError:
            logger.warning(
                "vip_removal_forbidden_bot_lacks_rights",
                user_id=user.id,
                telegram_id=user.telegram_id,
            )
            return False
        except TelegramBadRequest as exc:
            logger.warning(
                "vip_removal_bad_request",
                user_id=user.id,
                telegram_id=user.telegram_id,
                error=str(exc),
            )
            return False

    async def get_member_status(self, user: User) -> str | None:
        try:
            member = await self.bot.get_chat_member(
                chat_id=self.settings.vip_channel_id, user_id=user.telegram_id
            )
            return member.status
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            logger.warning(
                "vip_member_status_check_failed",
                user_id=user.id,
                error=str(exc),
            )
            return None
