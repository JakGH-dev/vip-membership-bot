from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from aiogram import Bot
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging_config import get_logger
from app.config.settings import Settings
from app.database.models.payment import Payment, PaymentProviderName, PaymentStatus
from app.database.models.plan import SubscriptionPlan
from app.database.repositories.payment_repo import DuplicatePaymentError, PaymentRepository
from app.database.repositories.plan_repo import PlanRepository
from app.database.repositories.promo_repo import PromoRepository
from app.services.payment_providers.base import InvoiceRequest, PaymentProvider
from app.services.promo_service import PromoService
from app.services.subscription_service import SubscriptionService

logger = get_logger(__name__)


@dataclass(frozen=True)
class PriceQuote:
    base_price: float
    discount: float
    final_price: float
    currency: str
    promo_code_id: Optional[int]


class PaymentValidationError(Exception):
    pass


class PaymentService:
    def __init__(
        self,
        session: AsyncSession,
        settings: Settings,
        provider: PaymentProvider,
    ) -> None:
        self.session = session
        self.settings = settings
        self.provider = provider
        self.payment_repo = PaymentRepository(session)
        self.plan_repo = PlanRepository(session)
        self.promo_repo = PromoRepository(session)
        self.promo_service = PromoService(session)
        self.subscription_service = SubscriptionService(session)

    async def quote_price(
        self, plan: SubscriptionPlan, user_id: int, promo_code: Optional[str]
    ) -> PriceQuote:
        base_price = float(plan.price)
        if not promo_code:
            return PriceQuote(
                base_price=base_price,
                discount=0.0,
                final_price=base_price,
                currency=plan.currency,
                promo_code_id=None,
            )

        promo = await self.promo_service.validate_and_get(promo_code, plan.id, user_id)
        discount = promo.compute_discount(base_price)
        final_price = round(max(0.0, base_price - discount), 2)
        return PriceQuote(
            base_price=base_price,
            discount=discount,
            final_price=final_price,
            currency=plan.currency,
            promo_code_id=promo.id,
        )

    async def create_pending_payment_and_invoice(
        self,
        bot: Bot,
        chat_id: int,
        user_id: int,
        plan: SubscriptionPlan,
        promo_code: Optional[str] = None,
    ) -> Payment:
        from app.utils.codes import generate_invoice_payload, generate_pending_payment_reference

        if not plan.is_active:
            raise PaymentValidationError("This plan is no longer available")

        quote = await self.quote_price(plan, user_id, promo_code)
        if quote.final_price <= 0:
            raise PaymentValidationError(
                "Discounted price must be greater than zero for paid checkout"
            )

        payload = generate_invoice_payload()
        pending_reference = generate_pending_payment_reference()

        payment = await self.payment_repo.create_pending(
            user_id=user_id,
            plan_id=plan.id,
            provider=PaymentProviderName.TELEGRAM,
            invoice_payload=payload,
            pending_reference=pending_reference,
            amount=quote.final_price,
            currency=quote.currency,
            discount_amount=quote.discount,
            promo_code_id=quote.promo_code_id,
        )

        invoice = InvoiceRequest(
            chat_id=chat_id,
            title=plan.name,
            description=plan.description or f"VIP access for {plan.duration_days} days",
            payload=payload,
            amount=quote.final_price,
            currency=quote.currency,
        )
        await self.provider.send_invoice(bot, invoice)
        return payment

    async def confirm_payment_from_provider(
        self,
        invoice_payload: str,
        provider_update: dict,
    ) -> Payment:
        """The ONLY path that may grant VIP access.

        Must be called exclusively from a verified provider confirmation
        (e.g. Telegram's `successful_payment` field on an incoming message,
        which Telegram itself generates after the provider approves the
        charge). Never call this based on a user's textual claim.
        """
        payment = await self.payment_repo.get_by_invoice_payload(invoice_payload)
        if payment is None:
            raise PaymentValidationError(
                f"No pending payment found for payload {invoice_payload}"
            )

        if payment.status == PaymentStatus.PAID:
            logger.info("payment_already_confirmed_idempotent", payment_id=payment.id)
            return payment

        if payment.is_final():
            raise PaymentValidationError(
                f"Payment {payment.id} is already in a final state: {payment.status}"
            )

        provider_payment_id = self.provider.extract_provider_payment_id(provider_update)

        existing_by_charge = await self.payment_repo.get_by_provider_payment_id(
            provider_payment_id
        )
        if existing_by_charge is not None and existing_by_charge.id != payment.id:
            logger.warning(
                "duplicate_provider_charge_detected",
                provider_payment_id=provider_payment_id,
                existing_payment_id=existing_by_charge.id,
                new_payment_id=payment.id,
            )
            raise DuplicatePaymentError(
                f"Charge {provider_payment_id} already applied to payment "
                f"{existing_by_charge.id}"
            )

        confirmed = await self.payment_repo.mark_paid(payment, provider_payment_id)

        if confirmed.promo_code_id is not None:
            promo = await self.promo_repo.get_by_id(confirmed.promo_code_id)
            if promo is not None:
                await self.promo_repo.increment_usage(promo)
                await self.promo_repo.record_usage(
                    promo_id=promo.id, user_id=confirmed.user_id, payment_id=confirmed.id
                )

        plan = await self.plan_repo.get_by_id(confirmed.plan_id)
        if plan is None:
            raise PaymentValidationError(
                f"Plan {confirmed.plan_id} referenced by payment {confirmed.id} no longer exists"
            )

        await self.subscription_service.grant_subscription(
            user_id=confirmed.user_id, plan=plan, payment_id=confirmed.id
        )

        logger.info(
            "payment_confirmed",
            payment_id=confirmed.id,
            user_id=confirmed.user_id,
            plan_id=confirmed.plan_id,
            provider_payment_id=provider_payment_id,
        )
        return confirmed

    async def expire_stale_pending_payments(self, older_than_minutes: int = 60) -> int:
        from datetime import timedelta

        from app.utils.datetime_utils import utcnow

        cutoff = utcnow() - timedelta(minutes=older_than_minutes)
        stale = await self.payment_repo.list_expired_pending(cutoff)
        count = 0
        for payment in stale:
            await self.payment_repo.mark_status(payment, PaymentStatus.EXPIRED)
            count += 1
        return count
