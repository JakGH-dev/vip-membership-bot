from __future__ import annotations

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging_config import get_logger
from app.database.models.subscription import Subscription
from app.database.models.user import User
from app.database.repositories.notification_repo import NotificationLogRepository
from app.database.repositories.user_repo import UserRepository
from app.utils.datetime_utils import format_remaining

logger = get_logger(__name__)


def _renew_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔄 Renew VIP", callback_data="subscribe:renew")]
        ]
    )


class NotificationService:
    def __init__(self, session: AsyncSession, bot: Bot) -> None:
        self.session = session
        self.bot = bot
        self.notification_repo = NotificationLogRepository(session)
        self.user_repo = UserRepository(session)

    async def send_expiration_warning(
        self, subscription: Subscription, threshold_minutes: int, remaining_seconds: float
    ) -> bool:
        user = await self.user_repo.get_by_id(subscription.user_id)
        if user is None or user.is_bot_blocked:
            return False

        remaining_text = format_remaining(remaining_seconds)
        text = (
            f"⚠️ Your VIP subscription will expire in {remaining_text}.\n\n"
            "Renew now to keep uninterrupted access to the VIP channel."
        )
        delivered = await self._safe_send(user.telegram_id, text, _renew_keyboard())
        await self.notification_repo.log(
            user_id=user.id,
            subscription_id=subscription.id,
            notification_type="expiration_warning",
            threshold_minutes=threshold_minutes,
            delivered=delivered,
        )
        return delivered

    async def send_expired_notice(self, subscription: Subscription) -> bool:
        user = await self.user_repo.get_by_id(subscription.user_id)
        if user is None or user.is_bot_blocked:
            return False

        text = (
            "❌ Your VIP subscription has expired and your access to the VIP "
            "channel has been removed.\n\nRenew anytime to get back in."
        )
        delivered = await self._safe_send(user.telegram_id, text, _renew_keyboard())
        await self.notification_repo.log(
            user_id=user.id,
            subscription_id=subscription.id,
            notification_type="expired",
            threshold_minutes=0,
            delivered=delivered,
        )
        return delivered

    async def send_plain_message(self, user: User, text: str) -> bool:
        if user.is_bot_blocked:
            return False
        return await self._safe_send(user.telegram_id, text, None)

    async def _safe_send(
        self, telegram_id: int, text: str, keyboard: InlineKeyboardMarkup | None
    ) -> bool:
        try:
            await self.bot.send_message(chat_id=telegram_id, text=text, reply_markup=keyboard)
            return True
        except TelegramRetryAfter as exc:
            logger.warning("notification_rate_limited", telegram_id=telegram_id, retry_after=exc.retry_after)
            return False
        except TelegramForbiddenError:
            user = await self.user_repo.get_by_telegram_id(telegram_id)
            if user is not None:
                await self.user_repo.set_bot_blocked(user, True)
            logger.info("notification_user_blocked_bot", telegram_id=telegram_id)
            return False
        except Exception as exc:  # noqa: BLE001 - must never crash the worker
            logger.error("notification_send_failed", telegram_id=telegram_id, error=str(exc))
            return False
