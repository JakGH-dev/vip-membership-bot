from __future__ import annotations

from aiogram import Bot
from aiogram.types import LabeledPrice

from app.config.logging_config import get_logger
from app.services.payment_providers.base import InvoiceRequest, PaymentProvider

logger = get_logger(__name__)


class TelegramPaymentsProvider(PaymentProvider):
    """Wraps Telegram Bot API native payments (Bot API `sendInvoice`).

    Amounts are expressed in the smallest currency unit (e.g. cents), as
    required by the Telegram Bot API.
    """

    name = "telegram"

    def __init__(self, provider_token: str) -> None:
        self._provider_token = provider_token

    async def send_invoice(self, bot: Bot, request: InvoiceRequest) -> None:
        amount_minor_units = int(round(request.amount * 100))
        prices = [LabeledPrice(label=request.title, amount=amount_minor_units)]
        await bot.send_invoice(
            chat_id=request.chat_id,
            title=request.title[:32] if len(request.title) > 32 else request.title,
            description=request.description[:255],
            payload=request.payload,
            provider_token=self._provider_token,
            currency=request.currency,
            prices=prices,
            start_parameter=request.payload,
        )
        logger.info(
            "invoice_sent",
            chat_id=request.chat_id,
            payload=request.payload,
            amount=request.amount,
            currency=request.currency,
        )

    def extract_provider_payment_id(self, update_payload: dict) -> str:
        # update_payload is expected to be the dict form of a
        # aiogram.types.SuccessfulPayment object (message.successful_payment).
        provider_charge_id = update_payload.get("provider_payment_charge_id")
        telegram_charge_id = update_payload.get("telegram_payment_charge_id")
        if not provider_charge_id and not telegram_charge_id:
            raise ValueError("Successful payment update is missing charge identifiers")
        # telegram_payment_charge_id is globally unique per successful payment
        # and is the most reliable idempotency key.
        return telegram_charge_id or provider_charge_id
