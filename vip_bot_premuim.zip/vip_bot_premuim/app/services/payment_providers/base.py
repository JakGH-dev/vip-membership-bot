from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from aiogram import Bot

from app.database.models.plan import SubscriptionPlan


@dataclass(frozen=True)
class InvoiceRequest:
    chat_id: int
    title: str
    description: str
    payload: str
    amount: float
    currency: str


class PaymentProvider(ABC):
    """Abstract interface every payment provider must implement.

    A confirmation of payment must always come from the provider itself
    (a Telegram successful_payment update, a Stripe webhook, etc). Handlers
    must never grant VIP access based on a user's own claim of payment.
    """

    name: str

    @abstractmethod
    async def send_invoice(self, bot: Bot, request: InvoiceRequest) -> None:
        raise NotImplementedError

    @abstractmethod
    def extract_provider_payment_id(self, update_payload: dict) -> str:
        """Return the provider's own unique charge/transaction id from a
        confirmed-payment update, to be used for idempotency checks."""
        raise NotImplementedError
