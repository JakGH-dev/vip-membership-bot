from __future__ import annotations

from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging_config import get_logger
from app.config.settings import Settings
from app.database.models.referral import Referral, ReferralRewardType
from app.database.models.user import User
from app.database.repositories.referral_repo import ReferralRepository
from app.database.repositories.settings_repo import BotSettingRepository
from app.database.repositories.user_repo import UserRepository
from app.services.subscription_service import SubscriptionService

logger = get_logger(__name__)

SETTING_REFERRAL_REWARD_DAYS = "referral_reward_days"


class ReferralService:
    def __init__(self, session: AsyncSession, settings: Settings) -> None:
        self.session = session
        self.settings = settings
        self.referral_repo = ReferralRepository(session)
        self.user_repo = UserRepository(session)
        self.settings_repo = BotSettingRepository(session)
        self.subscription_service = SubscriptionService(session)

    async def resolve_reward_days(self) -> int:
        return await self._resolve_reward_days()

    async def _resolve_reward_days(self) -> int:
        override = await self.settings_repo.get_value(SETTING_REFERRAL_REWARD_DAYS, "")
        if override:
            try:
                return int(override)
            except ValueError:
                logger.warning("invalid_referral_reward_days_override", value=override)
        return self.settings.referral_reward_days

    async def register_referral(
        self, referrer: User, new_user: User
    ) -> Optional[Referral]:
        """Registers that `new_user` was referred by `referrer`.

        Guards against self-referral and duplicate referral registration.
        Returns None (no-op) if the referral is invalid rather than raising,
        since referral abuse should fail silently from the new user's
        perspective (registration must still succeed).
        """
        if referrer.id == new_user.id:
            return None

        already_referred = await self.referral_repo.get_by_referred_user(new_user.id)
        if already_referred is not None:
            return None

        referral = await self.referral_repo.create(
            referrer_id=referrer.id, referred_user_id=new_user.id
        )
        return referral

    async def grant_signup_reward_if_eligible(self, referral: Referral) -> bool:
        """Grants the referrer their configured VIP-day reward for a new
        signup. Kept separate from `register_referral` so admins can choose
        to trigger rewards only after e.g. the referred user's first
        payment, by not calling this immediately at signup."""
        reward_days = await self._resolve_reward_days()
        if reward_days <= 0:
            return False

        reward = await self.referral_repo.create_reward(
            referrer_id=referral.referrer_id,
            referral_id=referral.id,
            reward_type=ReferralRewardType.VIP_DAYS,
            reward_value=float(reward_days),
        )
        await self.subscription_service.grant_bonus_days(referral.referrer_id, reward_days)
        await self.referral_repo.mark_reward_applied(reward)
        return True

    async def get_stats(self, user_id: int) -> dict:
        total_referrals = await self.referral_repo.count_for_referrer(user_id)
        rewarded_days = await self.referral_repo.sum_rewarded_days(user_id)
        return {
            "total_referrals": total_referrals,
            "rewarded_days": rewarded_days,
        }

