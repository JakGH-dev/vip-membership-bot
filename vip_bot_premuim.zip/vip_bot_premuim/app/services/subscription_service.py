from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.plan import SubscriptionPlan
from app.database.models.subscription import Subscription, SubscriptionStatus
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.subscription_repo import SubscriptionRepository
from app.utils.datetime_utils import utcnow


class SubscriptionService:
    """Owns all logic for creating, extending, and expiring memberships."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.subscription_repo = SubscriptionRepository(session)
        self.audit_repo = AuditLogRepository(session)

    async def get_active_subscription(self, user_id: int) -> Optional[Subscription]:
        return await self.subscription_repo.get_active_for_user(user_id, utcnow())

    async def grant_subscription(
        self,
        user_id: int,
        plan: SubscriptionPlan,
        payment_id: Optional[int],
    ) -> Subscription:
        """Create or extend the user's membership.

        If the user already has remaining active time, the new plan's
        duration is stacked on top of the remaining time instead of
        overwriting it (10 days remaining + 30-day plan = 40 days).
        """
        now = utcnow()
        existing = await self.subscription_repo.get_active_for_user(user_id, now)

        if existing is not None:
            new_expires_at = existing.expires_at + timedelta(days=plan.duration_days)
            updated = await self.subscription_repo.extend(existing, new_expires_at)
            return updated

        starts_at = now
        expires_at = now + timedelta(days=plan.duration_days)
        return await self.subscription_repo.create(
            user_id=user_id,
            plan_id=plan.id,
            payment_id=payment_id,
            starts_at=starts_at,
            expires_at=expires_at,
            status=SubscriptionStatus.ACTIVE,
        )

    async def grant_bonus_days(self, user_id: int, days: int) -> Subscription:
        """Used by referral rewards and manual admin grants.

        Extends the user's active subscription if one exists. Otherwise a
        new subscription record is created, attributed to the plan the user
        most recently held (or, for a brand-new user, the cheapest active
        plan), so the bonus days are still tracked against a real plan.
        """
        now = utcnow()
        existing = await self.subscription_repo.get_active_for_user(user_id, now)
        if existing is not None:
            new_expires_at = existing.expires_at + timedelta(days=days)
            return await self.subscription_repo.extend(existing, new_expires_at)

        plan_id = await self._resolve_fallback_plan_id(user_id)
        expires_at = now + timedelta(days=days)
        return await self.subscription_repo.create(
            user_id=user_id,
            plan_id=plan_id,
            payment_id=None,
            starts_at=now,
            expires_at=expires_at,
            status=SubscriptionStatus.ACTIVE,
        )

    async def _resolve_fallback_plan_id(self, user_id: int) -> int:
        from app.database.repositories.plan_repo import PlanRepository

        history = await self.subscription_repo.list_for_user(user_id)
        if history:
            return history[0].plan_id

        plan_repo = PlanRepository(self.session)
        active_plans = await plan_repo.list_active()
        if not active_plans:
            raise ValueError(
                "Cannot grant bonus days: no subscription plans exist to attribute them to"
            )
        cheapest = min(active_plans, key=lambda p: float(p.price))
        return cheapest.id

    async def cancel_auto_renew(self, subscription: Subscription) -> Subscription:
        subscription.auto_renew = False
        await self.session.flush()
        return subscription

    async def enable_auto_renew(self, subscription: Subscription) -> Subscription:
        subscription.auto_renew = True
        await self.session.flush()
        return subscription

    async def suspend(self, subscription: Subscription, admin_user_id: int) -> Subscription:
        updated = await self.subscription_repo.set_status(
            subscription, SubscriptionStatus.SUSPENDED
        )
        await self.audit_repo.log(
            admin_user_id=admin_user_id,
            action="subscription_suspend",
            target_type="subscription",
            target_id=str(subscription.id),
        )
        return updated

    async def unsuspend(self, subscription: Subscription, admin_user_id: int) -> Subscription:
        status = (
            SubscriptionStatus.ACTIVE
            if subscription.expires_at > utcnow()
            else SubscriptionStatus.EXPIRED
        )
        updated = await self.subscription_repo.set_status(subscription, status)
        await self.audit_repo.log(
            admin_user_id=admin_user_id,
            action="subscription_unsuspend",
            target_type="subscription",
            target_id=str(subscription.id),
        )
        return updated

    async def expire_due_subscriptions(self) -> list[Subscription]:
        now = utcnow()
        expired = await self.subscription_repo.list_expired(now)
        results = []
        for subscription in expired:
            updated = await self.subscription_repo.set_status(
                subscription, SubscriptionStatus.EXPIRED
            )
            results.append(updated)
        return results
