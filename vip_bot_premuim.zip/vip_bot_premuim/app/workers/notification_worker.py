from __future__ import annotations

from datetime import timedelta

from aiogram import Bot
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging_config import get_logger
from app.config.settings import Settings
from app.database.repositories.settings_repo import BotSettingRepository
from app.database.repositories.subscription_repo import SubscriptionRepository
from app.database.session import session_scope
from app.services.notification_service import NotificationService
from app.utils.datetime_utils import utcnow

logger = get_logger(__name__)


async def _resolve_thresholds(session: AsyncSession, settings: Settings) -> list[int]:
    settings_repo = BotSettingRepository(session)
    override = await settings_repo.get_value("notification_thresholds_minutes", "")
    if override:
        try:
            return sorted(
                {int(v.strip()) for v in override.split(",") if v.strip()}, reverse=True
            )
        except ValueError:
            logger.warning("invalid_notification_thresholds_override", value=override)
    return settings.notification_thresholds_minutes


async def run_notification_job(bot: Bot, settings: Settings) -> None:
    """Runs on a fixed interval. For each configured threshold (e.g. 3 days,
    24 hours, 1 hour before expiry), finds subscriptions entering that
    window for the first time and sends a warning, using a per-subscription
    notified-thresholds ledger to guarantee each warning is sent exactly
    once."""
    async with session_scope() as session:
        thresholds = await _resolve_thresholds(session, settings)
        if not thresholds:
            return

        subscription_repo = SubscriptionRepository(session)
        notification_service = NotificationService(session, bot)
        now = utcnow()

        # Sort ascending so the smallest window (closest to expiry) is
        # evaluated last, matching the natural urgency progression.
        for threshold_minutes in sorted(thresholds):
            deadline = now + timedelta(minutes=threshold_minutes)
            min_deadline = now
            candidates = await subscription_repo.list_expiring_within(
                now=now, deadline=deadline, min_deadline=min_deadline
            )

            for subscription in candidates:
                if subscription_repo.has_threshold_been_notified(
                    subscription, threshold_minutes
                ):
                    continue

                remaining_seconds = subscription.remaining_seconds(now)
                delivered = await notification_service.send_expiration_warning(
                    subscription, threshold_minutes, remaining_seconds
                )
                await subscription_repo.mark_threshold_notified(subscription, threshold_minutes)

                logger.info(
                    "expiration_warning_processed",
                    subscription_id=subscription.id,
                    threshold_minutes=threshold_minutes,
                    delivered=delivered,
                )
