from __future__ import annotations

from aiogram import Bot
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging_config import get_logger
from app.config.settings import Settings
from app.database.repositories.user_repo import UserRepository
from app.database.session import session_scope
from app.services.notification_service import NotificationService
from app.services.payment_service import PaymentService
from app.services.payment_providers.telegram_payments import TelegramPaymentsProvider
from app.services.subscription_service import SubscriptionService
from app.services.vip_channel_service import VipChannelService

logger = get_logger(__name__)


async def run_subscription_expiration_job(bot: Bot, settings: Settings) -> None:
    """Runs on a fixed interval. Finds subscriptions whose `expires_at` has
    passed, marks them expired, revokes VIP channel access, and notifies the
    user - independent of whether the user ever sends /start again."""
    async with session_scope() as session:
        subscription_service = SubscriptionService(session)
        vip_channel_service = VipChannelService(session, bot, settings)
        notification_service = NotificationService(session, bot)
        user_repo = UserRepository(session)

        expired_subscriptions = await subscription_service.expire_due_subscriptions()

        for subscription in expired_subscriptions:
            user = await user_repo.get_by_id(subscription.user_id)
            if user is None:
                continue

            removed = await vip_channel_service.remove_user_from_channel(user)
            await notification_service.send_expired_notice(subscription)

            logger.info(
                "subscription_expired_processed",
                subscription_id=subscription.id,
                user_id=user.id,
                vip_removed=removed,
            )

        if expired_subscriptions:
            logger.info("expiration_job_completed", count=len(expired_subscriptions))


async def run_stale_payment_cleanup_job(settings: Settings) -> None:
    """Marks pending payments that were never confirmed by Telegram within
    a reasonable window as expired, so they stop blocking idempotency
    lookups and clutter the admin payments view."""
    async with session_scope() as session:
        provider = TelegramPaymentsProvider(settings.telegram_payments_provider_token)
        payment_service = PaymentService(session, settings, provider)
        count = await payment_service.expire_stale_pending_payments(older_than_minutes=60)
        if count:
            logger.info("stale_payments_expired", count=count)
