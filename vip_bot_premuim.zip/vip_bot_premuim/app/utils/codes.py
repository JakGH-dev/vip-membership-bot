from __future__ import annotations

import secrets
import string
import uuid

_ALPHABET = string.ascii_uppercase + string.digits


def generate_referral_code(length: int = 8) -> str:
    return "".join(secrets.choice(_ALPHABET) for _ in range(length))


def generate_invoice_payload() -> str:
    return f"inv_{uuid.uuid4().hex}"


def generate_pending_payment_reference() -> str:
    return f"pending_{uuid.uuid4().hex}"
