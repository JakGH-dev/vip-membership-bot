from __future__ import annotations

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.bot.handlers import build_root_router
from app.bot.handlers.errors import router as errors_router
from app.bot.middlewares.db_middleware import DatabaseSessionMiddleware
from app.bot.middlewares.throttling import ThrottlingMiddleware
from app.config.logging_config import configure_logging, get_logger
from app.config.settings import get_settings
from app.database.session import dispose_engine
from app.workers.notification_worker import run_notification_job
from app.workers.subscription_expiration import (
    run_stale_payment_cleanup_job,
    run_subscription_expiration_job,
)

logger = get_logger(__name__)


def build_dispatcher(admin_ids: set[int], redis_url: str) -> Dispatcher:
    storage = RedisStorage.from_url(redis_url)
    dispatcher = Dispatcher(storage=storage)

    dispatcher.update.outer_middleware(ThrottlingMiddleware())
    dispatcher.update.outer_middleware(DatabaseSessionMiddleware(admin_ids=admin_ids))

    dispatcher.include_router(errors_router)
    dispatcher.include_router(build_root_router())

    return dispatcher


def build_scheduler(bot: Bot, settings) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="UTC")

    scheduler.add_job(
        run_subscription_expiration_job,
        trigger="interval",
        seconds=settings.expiration_check_interval_seconds,
        args=[bot, settings],
        id="subscription_expiration_job",
        max_instances=1,
        coalesce=True,
        misfire_grace_time=30,
    )

    scheduler.add_job(
        run_notification_job,
        trigger="interval",
        seconds=settings.notification_check_interval_seconds,
        args=[bot, settings],
        id="notification_job",
        max_instances=1,
        coalesce=True,
        misfire_grace_time=30,
    )

    scheduler.add_job(
        run_stale_payment_cleanup_job,
        trigger="interval",
        minutes=15,
        args=[settings],
        id="stale_payment_cleanup_job",
        max_instances=1,
        coalesce=True,
        misfire_grace_time=60,
    )

    return scheduler


async def main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)

    logger.info("starting_bot", environment=settings.environment)

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    admin_ids = set(settings.admin_ids)
    dispatcher = build_dispatcher(admin_ids, settings.redis_url)

    scheduler = build_scheduler(bot, settings)
    scheduler.start()

    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dispatcher.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await dispatcher.storage.close()
        await bot.session.close()
        await dispose_engine()
        logger.info("bot_stopped")


if __name__ == "__main__":
    asyncio.run(main())
