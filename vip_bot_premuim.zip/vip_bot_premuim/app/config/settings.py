from __future__ import annotations

from functools import lru_cache
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Telegram
    bot_token: str = Field(alias="BOT_TOKEN")
    admin_ids: List[int] = Field(default_factory=list, alias="ADMIN_IDS")
    vip_channel_id: int = Field(alias="VIP_CHANNEL_ID")

    # Payments
    telegram_payments_provider_token: str = Field(alias="TELEGRAM_PAYMENTS_PROVIDER_TOKEN")
    payment_currency: str = Field(default="USD", alias="PAYMENT_CURRENCY")

    # Database
    database_url: str = Field(alias="DATABASE_URL")

    # Redis
    redis_url: str = Field(alias="REDIS_URL")

    # App
    environment: str = Field(default="production", alias="ENVIRONMENT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    timezone: str = Field(default="UTC", alias="TIMEZONE")

    # Notifications
    notification_thresholds_minutes: List[int] = Field(
        default_factory=lambda: [4320, 1440, 60],
        alias="NOTIFICATION_THRESHOLDS_MINUTES",
    )

    # Referral
    referral_reward_days: int = Field(default=3, alias="REFERRAL_REWARD_DAYS")

    # Scheduler
    expiration_check_interval_seconds: int = Field(
        default=60, alias="EXPIRATION_CHECK_INTERVAL_SECONDS"
    )
    notification_check_interval_seconds: int = Field(
        default=60, alias="NOTIFICATION_CHECK_INTERVAL_SECONDS"
    )

    # Invite links
    vip_invite_link_expire_seconds: int = Field(
        default=3600, alias="VIP_INVITE_LINK_EXPIRE_SECONDS"
    )
    vip_invite_link_member_limit: int = Field(
        default=1, alias="VIP_INVITE_LINK_MEMBER_LIMIT"
    )

    @field_validator("admin_ids", mode="before")
    @classmethod
    def _parse_admin_ids(cls, value: object) -> List[int]:
        if isinstance(value, str):
            return [int(v.strip()) for v in value.split(",") if v.strip()]
        if isinstance(value, list):
            return [int(v) for v in value]
        return []

    @field_validator("notification_thresholds_minutes", mode="before")
    @classmethod
    def _parse_thresholds(cls, value: object) -> List[int]:
        if isinstance(value, str):
            return sorted(
                (int(v.strip()) for v in value.split(",") if v.strip()), reverse=True
            )
        if isinstance(value, list):
            return sorted((int(v) for v in value), reverse=True)
        return [4320, 1440, 60]


@lru_cache
def get_settings() -> Settings:
    return Settings()
