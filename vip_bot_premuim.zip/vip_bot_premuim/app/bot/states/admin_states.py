from __future__ import annotations

from aiogram.fsm.state import State, StatesGroup


class AdminPlanStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_description = State()
    waiting_for_price = State()
    waiting_for_currency = State()
    waiting_for_duration = State()
    waiting_for_new_price = State()


class AdminPromoStates(StatesGroup):
    waiting_for_code = State()
    waiting_for_discount_type = State()
    waiting_for_discount_value = State()
    waiting_for_validity_days = State()
    waiting_for_max_uses_total = State()
    waiting_for_max_uses_per_user = State()
    waiting_for_plan_ids = State()


class AdminUserStates(StatesGroup):
    waiting_for_search_query = State()
    waiting_for_days_to_add = State()


class AdminBroadcastStates(StatesGroup):
    waiting_for_content = State()


class SubscribeStates(StatesGroup):
    waiting_for_promo_code = State()
