from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, TelegramObject

from app.config.logging_config import get_logger

logger = get_logger(__name__)


class AdminOnlyMiddleware(BaseMiddleware):
    """Rejects any update routed through an admin-only router unless the
    resolved `db_user` (set by DatabaseSessionMiddleware) is an admin and
    not suspended. This is enforced server-side on every callback/command,
    never trusted from client-side button visibility alone."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        db_user = data.get("db_user")

        if db_user is None or not db_user.is_admin or db_user.is_suspended:
            if isinstance(event, CallbackQuery):
                await event.answer("🚫 Admins only.", show_alert=True)
            logger.warning(
                "unauthorized_admin_access_attempt",
                telegram_id=getattr(db_user, "telegram_id", None),
            )
            return None

        return await handler(event, data)
