from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, User as TgUser

from app.database.repositories.user_repo import UserRepository
from app.database.session import session_scope
from app.utils.codes import generate_referral_code


class DatabaseSessionMiddleware(BaseMiddleware):
    """Opens one DB session per update, commits on success, rolls back on
    error, and ensures a local `User` row exists for the Telegram sender."""

    def __init__(self, admin_ids: set[int]) -> None:
        super().__init__()
        self.admin_ids = admin_ids

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        async with session_scope() as session:
            data["session"] = session

            tg_user: TgUser | None = data.get("event_from_user")
            if tg_user is not None:
                user_repo = UserRepository(session)
                db_user = await user_repo.get_by_telegram_id(tg_user.id)
                if db_user is None:
                    db_user = await user_repo.create(
                        telegram_id=tg_user.id,
                        username=tg_user.username,
                        first_name=tg_user.first_name,
                        last_name=tg_user.last_name,
                        language_code=tg_user.language_code,
                        referral_code=generate_referral_code(),
                        is_admin=tg_user.id in self.admin_ids,
                    )
                else:
                    if db_user.is_admin != (tg_user.id in self.admin_ids):
                        db_user.is_admin = tg_user.id in self.admin_ids
                    await user_repo.update_profile(
                        db_user,
                        username=tg_user.username,
                        first_name=tg_user.first_name,
                        last_name=tg_user.last_name,
                        language_code=tg_user.language_code,
                    )
                data["db_user"] = db_user

            return await handler(event, data)
