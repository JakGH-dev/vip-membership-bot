from __future__ import annotations

import time
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject


class ThrottlingMiddleware(BaseMiddleware):
    """In-memory sliding-window throttle keyed by Telegram user id.

    Not distributed (single-process only) - sufficient to protect against a
    single user's rapid double-taps and basic flooding. For multi-instance
    deployments, back this with Redis (INCR + EXPIRE) instead.
    """

    def __init__(self, rate_limit_seconds: float = 0.6) -> None:
        super().__init__()
        self.rate_limit_seconds = rate_limit_seconds
        self._last_seen: Dict[int, float] = {}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is not None:
            now = time.monotonic()
            last = self._last_seen.get(user.id, 0.0)
            if now - last < self.rate_limit_seconds:
                if isinstance(event, CallbackQuery):
                    await event.answer("⏳ Please slow down a bit.")
                    return None
                if isinstance(event, Message):
                    return None
            self._last_seen[user.id] = now

        return await handler(event, data)
