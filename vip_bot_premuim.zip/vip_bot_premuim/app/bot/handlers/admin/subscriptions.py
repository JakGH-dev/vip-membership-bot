from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.bot.keyboards.admin_kb import admin_back_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.database.models.subscription import Subscription, SubscriptionStatus
from app.database.repositories.payment_repo import PaymentRepository
from app.database.repositories.user_repo import UserRepository
from app.utils.datetime_utils import format_datetime, format_remaining, utcnow

router = Router(name="admin_subs_payments")
router.callback_query.middleware(AdminOnlyMiddleware())
router.message.middleware(AdminOnlyMiddleware())


class AdminPaymentSearchStates(StatesGroup):
    waiting_for_query = State()


@router.callback_query(F.data == "admin:subs")
async def list_recent_subscriptions(callback: CallbackQuery, session: AsyncSession) -> None:
    result = await session.execute(
        select(Subscription)
        .options(selectinload(Subscription.plan), selectinload(Subscription.user))
        .order_by(Subscription.created_at.desc())
        .limit(15)
    )
    subscriptions = result.scalars().all()

    if not subscriptions:
        text = "💎 <b>Subscriptions</b>\n\nNo subscriptions yet."
    else:
        now = utcnow()
        lines = ["💎 <b>Recent Subscriptions</b>", ""]
        for sub in subscriptions:
            owner = sub.user.full_name() if sub.user else f"user #{sub.user_id}"
            status_icon = {
                SubscriptionStatus.ACTIVE: "✅",
                SubscriptionStatus.EXPIRED: "❌",
                SubscriptionStatus.CANCELLED: "🚫",
                SubscriptionStatus.SUSPENDED: "⏸",
            }.get(sub.status, "❔")
            remaining = (
                f" ({format_remaining(sub.remaining_seconds(now))} left)"
                if sub.status == SubscriptionStatus.ACTIVE
                else ""
            )
            lines.append(
                f"{status_icon} #{sub.id} {owner} — {sub.plan.name} — "
                f"exp {format_datetime(sub.expires_at)}{remaining}"
            )
        text = "\n".join(lines)

    await callback.message.edit_text(text, reply_markup=admin_back_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin:payments")
async def prompt_payment_search(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPaymentSearchStates.waiting_for_query)
    await callback.message.edit_text(
        "💳 <b>Payments</b>\n\n"
        "Send a transaction ID / invoice reference to search, or send 'recent' "
        "to see the latest payments.",
        reply_markup=admin_back_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AdminPaymentSearchStates.waiting_for_query)
async def handle_payment_search(message: Message, state: FSMContext, session: AsyncSession) -> None:
    await state.clear()
    payment_repo = PaymentRepository(session)
    user_repo = UserRepository(session)

    query = message.text.strip()
    payments = (
        await _recent_payments(session)
        if query.lower() == "recent"
        else await payment_repo.search(query, limit=15)
    )

    if not payments:
        await message.answer("No matching payments found.", reply_markup=admin_back_kb())
        return

    lines = ["💳 <b>Payment Results</b>", ""]
    for payment in payments:
        owner = await user_repo.get_by_id(payment.user_id)
        owner_name = owner.full_name() if owner else f"user #{payment.user_id}"
        lines.append(
            f"#{payment.id} • {owner_name} • {payment.amount} {payment.currency} • "
            f"{payment.status} • ref={payment.provider_payment_id} • "
            f"{format_datetime(payment.created_at)}"
        )
    await message.answer("\n".join(lines), reply_markup=admin_back_kb())


async def _recent_payments(session: AsyncSession):
    from app.database.models.payment import Payment

    result = await session.execute(
        select(Payment).order_by(Payment.created_at.desc()).limit(15)
    )
    return result.scalars().all()
