from __future__ import annotations

import asyncio

from aiogram import F, Router
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.admin_kb import admin_back_kb, admin_broadcast_confirm_kb, admin_cancel_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.bot.states.admin_states import AdminBroadcastStates
from app.config.logging_config import get_logger
from app.database.models.user import User
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.user_repo import UserRepository

logger = get_logger(__name__)
router = Router(name="admin_broadcast")
router.callback_query.middleware(AdminOnlyMiddleware())
router.message.middleware(AdminOnlyMiddleware())

BROADCAST_DELAY_SECONDS = 0.05  # keeps well under Telegram's ~30 msg/sec global limit


@router.callback_query(F.data == "admin:broadcast")
async def start_broadcast(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminBroadcastStates.waiting_for_content)
    await callback.message.edit_text(
        "📢 Send the text, photo, video, or document you want to broadcast to all users.",
        reply_markup=admin_back_kb("admin:open"),
    )
    await callback.answer()


@router.message(AdminBroadcastStates.waiting_for_content)
async def preview_broadcast(message: Message, state: FSMContext) -> None:
    await state.update_data(source_chat_id=message.chat.id, source_message_id=message.message_id)
    await state.set_state(None)

    await message.answer(
        "👆 This is a preview of your broadcast. Send it to all users?",
        reply_markup=admin_broadcast_confirm_kb(),
    )


@router.callback_query(F.data == "admin:broadcast:confirm")
async def confirm_broadcast(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession, db_user: User
) -> None:
    data = await state.get_data()
    source_chat_id = data.get("source_chat_id")
    source_message_id = data.get("source_message_id")
    await state.clear()

    if source_chat_id is None or source_message_id is None:
        await callback.answer("Nothing to broadcast. Please start over.", show_alert=True)
        return

    await callback.message.edit_text("📢 Broadcasting... this may take a while.")
    await callback.answer()

    user_repo = UserRepository(session)
    result = await session.execute(select(User).where(User.is_bot_blocked.is_(False)))
    users = result.scalars().all()

    success_count = 0
    failed_count = 0

    for user in users:
        try:
            await callback.bot.copy_message(
                chat_id=user.telegram_id,
                from_chat_id=source_chat_id,
                message_id=source_message_id,
            )
            success_count += 1
        except TelegramRetryAfter as exc:
            await asyncio.sleep(exc.retry_after)
            try:
                await callback.bot.copy_message(
                    chat_id=user.telegram_id,
                    from_chat_id=source_chat_id,
                    message_id=source_message_id,
                )
                success_count += 1
            except Exception:
                failed_count += 1
        except TelegramForbiddenError:
            await user_repo.set_bot_blocked(user, True)
            failed_count += 1
        except Exception as exc:  # noqa: BLE001 - one failure must not stop the broadcast
            logger.warning("broadcast_send_failed", telegram_id=user.telegram_id, error=str(exc))
            failed_count += 1

        await asyncio.sleep(BROADCAST_DELAY_SECONDS)

    audit_repo = AuditLogRepository(session)
    await audit_repo.log(
        db_user.id,
        "broadcast_sent",
        details=f"success={success_count} failed={failed_count}",
    )

    await callback.message.answer(
        f"✅ Broadcast finished.\n\nDelivered: {success_count}\nFailed: {failed_count}"
    )
