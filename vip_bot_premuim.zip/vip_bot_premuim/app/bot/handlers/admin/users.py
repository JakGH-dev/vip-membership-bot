from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.admin_kb import admin_back_kb, admin_user_actions_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.bot.states.admin_states import AdminUserStates
from app.database.models.user import User
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.payment_repo import PaymentRepository
from app.database.repositories.user_repo import UserRepository
from app.services.subscription_service import SubscriptionService
from app.services.vip_channel_service import VipChannelService
from app.config.settings import get_settings
from app.utils.datetime_utils import format_datetime, format_remaining, utcnow

router = Router(name="admin_users")
router.callback_query.middleware(AdminOnlyMiddleware())
router.message.middleware(AdminOnlyMiddleware())


def _search_prompt_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ Back", callback_data="admin:open")]]
    )


@router.callback_query(F.data == "admin:users")
async def prompt_user_search(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminUserStates.waiting_for_search_query)
    await callback.message.edit_text(
        "👥 <b>Users</b>\n\nSend a Telegram ID or username to search.",
        reply_markup=_search_prompt_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AdminUserStates.waiting_for_search_query)
async def handle_user_search(message: Message, state: FSMContext, session: AsyncSession) -> None:
    user_repo = UserRepository(session)
    results = await user_repo.search(message.text.strip(), limit=10)
    await state.clear()

    if not results:
        await message.answer("No users found.", reply_markup=_search_prompt_kb())
        return

    if len(results) == 1:
        await _render_user_profile(message, session, results[0])
        return

    rows = [
        [
            InlineKeyboardButton(
                text=f"{u.full_name()} (@{u.username})" if u.username else u.full_name(),
                callback_data=f"admin:user:view:{u.id}",
            )
        ]
        for u in results
    ]
    rows.append([InlineKeyboardButton(text="⬅️ Back", callback_data="admin:open")])
    await message.answer("Multiple matches found:", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("admin:user:view:"))
async def view_user_profile(callback: CallbackQuery, session: AsyncSession) -> None:
    user_id = int(callback.data.split(":")[-1])
    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(user_id)
    if user is None:
        await callback.answer("User not found.", show_alert=True)
        return
    await _render_user_profile(callback.message, session, user, edit=True)
    await callback.answer()


async def _render_user_profile(message: Message, session: AsyncSession, user: User, edit: bool = False) -> None:
    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(user.id)
    payment_repo = PaymentRepository(session)
    payments = await payment_repo.list_for_user(user.id, limit=1000)

    lines = [
        f"👤 <b>{user.full_name()}</b>",
        f"Telegram ID: <code>{user.telegram_id}</code>",
        f"Username: @{user.username}" if user.username else "Username: —",
        f"Admin: {'Yes' if user.is_admin else 'No'}",
        f"Suspended: {'Yes' if user.is_suspended else 'No'}",
        "",
    ]
    if subscription is not None:
        now = utcnow()
        lines += [
            f"VIP status: ✅ Active ({subscription.plan.name})",
            f"Expires: {format_datetime(subscription.expires_at)} "
            f"({format_remaining(subscription.remaining_seconds(now))} left)",
        ]
    else:
        lines += ["VIP status: ❌ Not subscribed"]

    lines += [f"Total payments: {len(payments)}"]

    text = "\n".join(lines)
    keyboard = admin_user_actions_kb(user.id, user.is_suspended)
    if edit:
        await message.edit_text(text, reply_markup=keyboard, parse_mode="HTML")
    else:
        await message.answer(text, reply_markup=keyboard, parse_mode="HTML")


@router.callback_query(F.data.startswith("admin:user:suspend:"))
async def suspend_user(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    user_id = int(callback.data.split(":")[-1])
    user_repo = UserRepository(session)
    target = await user_repo.get_by_id(user_id)
    if target is None:
        await callback.answer("User not found.", show_alert=True)
        return

    await user_repo.set_suspended(target, True)
    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "user_suspend", "user", str(target.id))

    await _render_user_profile(callback.message, session, target, edit=True)
    await callback.answer("User suspended.")


@router.callback_query(F.data.startswith("admin:user:unsuspend:"))
async def unsuspend_user(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    user_id = int(callback.data.split(":")[-1])
    user_repo = UserRepository(session)
    target = await user_repo.get_by_id(user_id)
    if target is None:
        await callback.answer("User not found.", show_alert=True)
        return

    await user_repo.set_suspended(target, False)
    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "user_unsuspend", "user", str(target.id))

    await _render_user_profile(callback.message, session, target, edit=True)
    await callback.answer("User unsuspended.")


@router.callback_query(F.data.startswith("admin:user:removevip:"))
async def remove_vip(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    user_id = int(callback.data.split(":")[-1])
    user_repo = UserRepository(session)
    target = await user_repo.get_by_id(user_id)
    if target is None:
        await callback.answer("User not found.", show_alert=True)
        return

    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(target.id)
    if subscription is None:
        await callback.answer("User has no active subscription.", show_alert=True)
        return

    from app.database.models.subscription import SubscriptionStatus

    await subscription_service.subscription_repo.set_status(subscription, SubscriptionStatus.CANCELLED)

    settings = get_settings()
    vip_channel_service = VipChannelService(session, callback.bot, settings)
    await vip_channel_service.remove_user_from_channel(target)

    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "user_remove_vip", "subscription", str(subscription.id))

    await _render_user_profile(callback.message, session, target, edit=True)
    await callback.answer("VIP access removed.")


@router.callback_query(F.data.startswith("admin:user:adddays:"))
async def prompt_add_days(callback: CallbackQuery, state: FSMContext) -> None:
    user_id = int(callback.data.split(":")[-1])
    await state.set_state(AdminUserStates.waiting_for_days_to_add)
    await state.update_data(target_user_id=user_id)
    await callback.message.edit_text(
        "Send the number of VIP days to add for this user.",
        reply_markup=admin_back_kb(f"admin:user:view:{user_id}"),
    )
    await callback.answer()


@router.message(AdminUserStates.waiting_for_days_to_add)
async def handle_add_days(message: Message, state: FSMContext, session: AsyncSession, db_user: User) -> None:
    data = await state.get_data()
    target_user_id = data.get("target_user_id")
    await state.clear()

    if not message.text or not message.text.strip().lstrip("-").isdigit():
        await message.answer("Please send a valid whole number of days.")
        return

    days = int(message.text.strip())
    if days <= 0:
        await message.answer("Number of days must be positive.")
        return

    user_repo = UserRepository(session)
    target = await user_repo.get_by_id(target_user_id)
    if target is None:
        await message.answer("User not found.")
        return

    subscription_service = SubscriptionService(session)
    try:
        await subscription_service.grant_bonus_days(target.id, days)
    except ValueError as exc:
        await message.answer(f"Could not add days: {exc}")
        return

    audit_repo = AuditLogRepository(session)
    await audit_repo.log(
        db_user.id, "user_add_days", "user", str(target.id), details=f"days={days}"
    )

    await message.answer(f"✅ Added {days} VIP day(s) to {target.full_name()}.")
    await _render_user_profile(message, session, target)


@router.callback_query(F.data.startswith("admin:user:payments:"))
async def view_user_payments(callback: CallbackQuery, session: AsyncSession) -> None:
    user_id = int(callback.data.split(":")[-1])
    payment_repo = PaymentRepository(session)
    payments = await payment_repo.list_for_user(user_id, limit=20)

    if not payments:
        text = "This user has no payments."
    else:
        lines = ["💳 <b>Payment History</b>", ""]
        for payment in payments:
            lines.append(
                f"#{payment.id} • {payment.amount} {payment.currency} • "
                f"{payment.status} • {format_datetime(payment.created_at)}"
            )
        text = "\n".join(lines)

    await callback.message.edit_text(
        text, reply_markup=admin_back_kb(f"admin:user:view:{user_id}"), parse_mode="HTML"
    )
    await callback.answer()
