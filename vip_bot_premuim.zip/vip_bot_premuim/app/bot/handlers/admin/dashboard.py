from __future__ import annotations

from datetime import timedelta

from aiogram import F, Router
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.admin_kb import admin_back_kb, admin_home_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.payment_repo import PaymentRepository
from app.database.repositories.referral_repo import ReferralRepository
from app.database.repositories.subscription_repo import SubscriptionRepository
from app.database.repositories.user_repo import UserRepository
from app.utils.datetime_utils import format_datetime, utcnow

router = Router(name="admin_dashboard")
router.callback_query.middleware(AdminOnlyMiddleware())


@router.callback_query(F.data == "admin:open")
async def open_admin_panel(callback: CallbackQuery) -> None:
    await callback.message.edit_text("🛠 <b>Admin Panel</b>", reply_markup=admin_home_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin:dashboard")
async def show_dashboard(callback: CallbackQuery, session: AsyncSession) -> None:
    user_repo = UserRepository(session)
    subscription_repo = SubscriptionRepository(session)
    payment_repo = PaymentRepository(session)

    now = utcnow()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start = now - timedelta(days=7)
    month_start = now - timedelta(days=30)

    total_users = await user_repo.count_total()
    new_today = await user_repo.count_created_since(today_start)
    active_vip = await subscription_repo.count_active(now)
    expired_vip = await subscription_repo.count_expired()

    revenue_today = await payment_repo.sum_amount_since(today_start)
    revenue_week = await payment_repo.sum_amount_since(week_start)
    revenue_month = await payment_repo.sum_amount_since(month_start)
    revenue_total = await payment_repo.sum_amount_total()

    payments_count = await payment_repo.count_all_total()
    paid_count = await payment_repo.count_paid_total()
    conversion_rate = (paid_count / payments_count * 100) if payments_count else 0.0

    text = (
        "📊 <b>Dashboard</b>\n\n"
        f"Total Users: {total_users}\n"
        f"New Users Today: {new_today}\n"
        f"Active VIP: {active_vip}\n"
        f"Expired VIP: {expired_vip}\n\n"
        f"Revenue Today: {revenue_today:.2f}\n"
        f"Revenue This Week: {revenue_week:.2f}\n"
        f"Revenue This Month: {revenue_month:.2f}\n"
        f"Total Revenue: {revenue_total:.2f}\n\n"
        f"Number of Payments: {payments_count}\n"
        f"Conversion Rate: {conversion_rate:.1f}%"
    )
    await callback.message.edit_text(text, reply_markup=admin_back_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin:referrals")
async def show_referrals_overview(callback: CallbackQuery, session: AsyncSession) -> None:
    referral_repo = ReferralRepository(session)
    user_repo = UserRepository(session)

    # Referral leaderboard: aggregate referral counts per referrer.
    from sqlalchemy import select, func as sa_func
    from app.database.models.referral import Referral

    result = await session.execute(
        select(Referral.referrer_id, sa_func.count(Referral.id).label("cnt"))
        .group_by(Referral.referrer_id)
        .order_by(sa_func.count(Referral.id).desc())
        .limit(10)
    )
    rows = result.all()

    if not rows:
        text = "🎁 <b>Referrals</b>\n\nNo referrals recorded yet."
    else:
        lines = ["🎁 <b>Top Referrers</b>", ""]
        for referrer_id, count in rows:
            user = await user_repo.get_by_id(referrer_id)
            name = user.full_name() if user else f"user #{referrer_id}"
            lines.append(f"{name}: {count} referral(s)")
        text = "\n".join(lines)

    await callback.message.edit_text(text, reply_markup=admin_back_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin:logs")
async def show_audit_logs(callback: CallbackQuery, session: AsyncSession) -> None:
    audit_repo = AuditLogRepository(session)
    logs = await audit_repo.list_recent(limit=20)

    if not logs:
        text = "📋 <b>Audit Logs</b>\n\nNo actions recorded yet."
    else:
        lines = ["📋 <b>Recent Admin Actions</b>", ""]
        for log in logs:
            target = f" [{log.target_type}#{log.target_id}]" if log.target_type else ""
            lines.append(f"{format_datetime(log.created_at)} • {log.action}{target}")
        text = "\n".join(lines)

    await callback.message.edit_text(text, reply_markup=admin_back_kb(), parse_mode="HTML")
    await callback.answer()
