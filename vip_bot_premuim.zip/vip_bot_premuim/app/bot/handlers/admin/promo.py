from __future__ import annotations

from datetime import timedelta

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.admin_kb import admin_back_kb, admin_promo_detail_kb, admin_promos_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.bot.states.admin_states import AdminPromoStates
from app.database.models.promo import PromoDiscountType
from app.database.models.user import User
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.promo_repo import PromoRepository
from app.utils.datetime_utils import format_datetime, utcnow

router = Router(name="admin_promos")
router.callback_query.middleware(AdminOnlyMiddleware())
router.message.middleware(AdminOnlyMiddleware())


def _discount_type_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="% Percent", callback_data="admin:promo:type:percent"),
                InlineKeyboardButton(text="Fixed amount", callback_data="admin:promo:type:fixed"),
            ]
        ]
    )


@router.callback_query(F.data == "admin:promos")
async def list_promos(callback: CallbackQuery, session: AsyncSession) -> None:
    promo_repo = PromoRepository(session)
    promos = await promo_repo.list_all()
    await callback.message.edit_text(
        "🎟 <b>Promo Codes</b>", reply_markup=admin_promos_kb(promos), parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin:promo:view:"))
async def view_promo(callback: CallbackQuery, session: AsyncSession) -> None:
    promo_id = int(callback.data.split(":")[-1])
    promo_repo = PromoRepository(session)
    promo = await promo_repo.get_by_id(promo_id)
    if promo is None:
        await callback.answer("Promo code not found.", show_alert=True)
        return

    discount_display = (
        f"{promo.discount_value}%" if promo.discount_type == PromoDiscountType.PERCENT
        else f"{promo.discount_value} (fixed)"
    )
    text = (
        f"🎟 <b>{promo.code}</b>\n\n"
        f"Discount: {discount_display}\n"
        f"Valid: {format_datetime(promo.valid_from)} → {format_datetime(promo.valid_until)}\n"
        f"Used: {promo.used_count}"
        + (f" / {promo.max_uses_total}" if promo.max_uses_total else " / unlimited")
        + "\n"
        f"Max per user: {promo.max_uses_per_user}\n"
        f"Applicable plans: {promo.applicable_plan_ids or 'All plans'}\n"
        f"Status: {'🟢 Active' if promo.is_active else '🔴 Inactive'}"
    )
    await callback.message.edit_text(text, reply_markup=admin_promo_detail_kb(promo), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("admin:promo:enable:"))
async def enable_promo(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    await _set_promo_active(callback, session, db_user, True)


@router.callback_query(F.data.startswith("admin:promo:disable:"))
async def disable_promo(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    await _set_promo_active(callback, session, db_user, False)


async def _set_promo_active(callback: CallbackQuery, session: AsyncSession, db_user: User, active: bool) -> None:
    promo_id = int(callback.data.split(":")[-1])
    promo_repo = PromoRepository(session)
    promo = await promo_repo.get_by_id(promo_id)
    if promo is None:
        await callback.answer("Promo code not found.", show_alert=True)
        return

    await promo_repo.set_active(promo, active)
    audit_repo = AuditLogRepository(session)
    await audit_repo.log(
        db_user.id, "promo_enable" if active else "promo_disable", "promo_code", str(promo.id)
    )

    await view_promo(callback, session)


@router.callback_query(F.data == "admin:promo:create")
async def start_create_promo(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPromoStates.waiting_for_code)
    await callback.message.edit_text(
        "Send the new promo code text (e.g. VIP50).",
        reply_markup=admin_back_kb("admin:promos"),
    )
    await callback.answer()


@router.message(AdminPromoStates.waiting_for_code)
async def handle_promo_code(message: Message, state: FSMContext, session: AsyncSession) -> None:
    code = message.text.strip().upper()
    if not code or " " in code:
        await message.answer("Please send a valid code with no spaces.")
        return

    promo_repo = PromoRepository(session)
    existing = await promo_repo.get_by_code(code)
    if existing is not None:
        await message.answer("This code already exists. Please choose another one.")
        return

    await state.update_data(code=code)
    await state.set_state(AdminPromoStates.waiting_for_discount_type)
    await message.answer("Choose the discount type:", reply_markup=_discount_type_kb())


@router.callback_query(F.data.startswith("admin:promo:type:"))
async def handle_promo_discount_type(callback: CallbackQuery, state: FSMContext) -> None:
    discount_type = callback.data.split(":")[-1]
    await state.update_data(discount_type=discount_type)
    await state.set_state(AdminPromoStates.waiting_for_discount_value)
    label = "percentage (e.g. 50 for 50%)" if discount_type == "percent" else "fixed amount (e.g. 5.00)"
    await callback.message.edit_text(f"Send the discount {label}.")
    await callback.answer()


@router.message(AdminPromoStates.waiting_for_discount_value)
async def handle_promo_discount_value(message: Message, state: FSMContext) -> None:
    try:
        value = float(message.text.strip().replace(",", "."))
        if value <= 0:
            raise ValueError
    except ValueError:
        await message.answer("Please send a valid positive number.")
        return

    await state.update_data(discount_value=value)
    await state.set_state(AdminPromoStates.waiting_for_validity_days)
    await message.answer("How many days should this code stay valid, starting now?")


@router.message(AdminPromoStates.waiting_for_validity_days)
async def handle_promo_validity(message: Message, state: FSMContext) -> None:
    if not message.text.strip().isdigit():
        await message.answer("Please send a valid whole number of days.")
        return

    await state.update_data(validity_days=int(message.text.strip()))
    await state.set_state(AdminPromoStates.waiting_for_max_uses_total)
    await message.answer("Max total uses across all users? Send 0 for unlimited.")


@router.message(AdminPromoStates.waiting_for_max_uses_total)
async def handle_promo_max_total(message: Message, state: FSMContext) -> None:
    if not message.text.strip().isdigit():
        await message.answer("Please send a valid whole number (0 for unlimited).")
        return

    max_total = int(message.text.strip())
    await state.update_data(max_uses_total=max_total if max_total > 0 else None)
    await state.set_state(AdminPromoStates.waiting_for_max_uses_per_user)
    await message.answer("Max uses per user? (e.g. 1)")


@router.message(AdminPromoStates.waiting_for_max_uses_per_user)
async def handle_promo_max_per_user(message: Message, state: FSMContext) -> None:
    if not message.text.strip().isdigit() or int(message.text.strip()) <= 0:
        await message.answer("Please send a positive whole number.")
        return

    await state.update_data(max_uses_per_user=int(message.text.strip()))
    await state.set_state(AdminPromoStates.waiting_for_plan_ids)
    await message.answer(
        "Send comma-separated plan IDs this code applies to, or send 'all' for every plan."
    )


@router.message(AdminPromoStates.waiting_for_plan_ids)
async def handle_promo_plan_ids(message: Message, state: FSMContext, session: AsyncSession, db_user: User) -> None:
    raw = message.text.strip().lower()
    applicable_plan_ids = "" if raw == "all" else message.text.strip()

    if applicable_plan_ids:
        parts = [p.strip() for p in applicable_plan_ids.split(",") if p.strip()]
        if not all(p.isdigit() for p in parts):
            await message.answer("Please send plan IDs as numbers separated by commas, or 'all'.")
            return
        applicable_plan_ids = ",".join(parts)

    data = await state.get_data()
    await state.clear()

    now = utcnow()
    valid_until = now + timedelta(days=data["validity_days"])

    discount_type = (
        PromoDiscountType.PERCENT if data["discount_type"] == "percent" else PromoDiscountType.FIXED
    )

    promo_repo = PromoRepository(session)
    promo = await promo_repo.create(
        code=data["code"],
        discount_type=discount_type,
        discount_value=data["discount_value"],
        valid_from=now,
        valid_until=valid_until,
        max_uses_total=data["max_uses_total"],
        max_uses_per_user=data["max_uses_per_user"],
        applicable_plan_ids=applicable_plan_ids,
    )

    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "promo_create", "promo_code", str(promo.id))

    await message.answer(f"✅ Promo code '{promo.code}' created.")
