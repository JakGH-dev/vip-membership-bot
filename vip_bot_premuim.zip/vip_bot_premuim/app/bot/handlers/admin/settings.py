from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.admin_kb import admin_back_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.database.models.user import User
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.settings_repo import BotSettingRepository

router = Router(name="admin_settings")
router.callback_query.middleware(AdminOnlyMiddleware())
router.message.middleware(AdminOnlyMiddleware())

SETTING_NOTIFICATION_THRESHOLDS = "notification_thresholds_minutes"
SETTING_REFERRAL_REWARD_DAYS = "referral_reward_days"

_SETTING_LABELS = {
    SETTING_NOTIFICATION_THRESHOLDS: "Expiration notification thresholds (minutes, comma-separated)",
    SETTING_REFERRAL_REWARD_DAYS: "Referral reward (VIP days per signup)",
}


class AdminSettingsStates(StatesGroup):
    waiting_for_value = State()


def _settings_kb() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text="⏰ Notification thresholds",
                callback_data=f"admin:setting:edit:{SETTING_NOTIFICATION_THRESHOLDS}",
            )
        ],
        [
            InlineKeyboardButton(
                text="🎁 Referral reward days",
                callback_data=f"admin:setting:edit:{SETTING_REFERRAL_REWARD_DAYS}",
            )
        ],
        [
            InlineKeyboardButton(text="⬅️ Back", callback_data="admin:open"),
            InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:settings")
async def show_settings(callback: CallbackQuery, session: AsyncSession) -> None:
    settings_repo = BotSettingRepository(session)
    thresholds = await settings_repo.get_value(SETTING_NOTIFICATION_THRESHOLDS, "not overridden (using .env default)")
    reward_days = await settings_repo.get_value(SETTING_REFERRAL_REWARD_DAYS, "not overridden (using .env default)")

    text = (
        "⚙️ <b>Bot Settings</b>\n\n"
        f"Notification thresholds: {thresholds}\n"
        f"Referral reward days: {reward_days}\n\n"
        "Tap a setting below to change it."
    )
    await callback.message.edit_text(text, reply_markup=_settings_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("admin:setting:edit:"))
async def prompt_setting_value(callback: CallbackQuery, state: FSMContext) -> None:
    key = callback.data.split(":", 3)[-1]
    label = _SETTING_LABELS.get(key, key)
    await state.set_state(AdminSettingsStates.waiting_for_value)
    await state.update_data(setting_key=key)
    await callback.message.edit_text(
        f"Send the new value for:\n<b>{label}</b>",
        reply_markup=admin_back_kb("admin:settings"),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AdminSettingsStates.waiting_for_value)
async def handle_setting_value(
    message: Message, state: FSMContext, session: AsyncSession, db_user: User
) -> None:
    data = await state.get_data()
    key = data.get("setting_key")
    await state.clear()

    value = message.text.strip()

    if key == SETTING_NOTIFICATION_THRESHOLDS:
        parts = [p.strip() for p in value.split(",") if p.strip()]
        if not all(p.isdigit() for p in parts) or not parts:
            await message.answer("Please send comma-separated whole numbers, e.g. 4320,1440,60.")
            return
        value = ",".join(parts)
    elif key == SETTING_REFERRAL_REWARD_DAYS:
        if not value.isdigit():
            await message.answer("Please send a whole number of days.")
            return
    else:
        await message.answer("Unknown setting.")
        return

    settings_repo = BotSettingRepository(session)
    await settings_repo.set(key, value, description=_SETTING_LABELS.get(key, ""))

    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "setting_update", "bot_setting", key, details=f"value={value}")

    await message.answer(f"✅ Setting updated: {_SETTING_LABELS.get(key, key)} = {value}")
