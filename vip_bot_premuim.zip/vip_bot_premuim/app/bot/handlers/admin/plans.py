from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.admin_kb import admin_back_kb, admin_plan_detail_kb, admin_plans_kb
from app.bot.middlewares.admin_middleware import AdminOnlyMiddleware
from app.bot.states.admin_states import AdminPlanStates
from app.database.models.user import User
from app.database.repositories.audit_repo import AuditLogRepository
from app.database.repositories.plan_repo import PlanRepository

router = Router(name="admin_plans")
router.callback_query.middleware(AdminOnlyMiddleware())
router.message.middleware(AdminOnlyMiddleware())


@router.callback_query(F.data == "admin:plans")
async def list_plans(callback: CallbackQuery, session: AsyncSession) -> None:
    plan_repo = PlanRepository(session)
    plans = await plan_repo.list_all()
    await callback.message.edit_text(
        "📦 <b>Subscription Plans</b>", reply_markup=admin_plans_kb(plans), parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin:plan:view:"))
async def view_plan(callback: CallbackQuery, session: AsyncSession) -> None:
    plan_id = int(callback.data.split(":")[-1])
    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)
    if plan is None:
        await callback.answer("Plan not found.", show_alert=True)
        return

    text = (
        f"📦 <b>{plan.name}</b>\n\n"
        f"{plan.description or '—'}\n\n"
        f"Price: {plan.price_display()}\n"
        f"Duration: {plan.duration_days} days\n"
        f"Status: {'🟢 Active' if plan.is_active else '🔴 Inactive'}"
    )
    await callback.message.edit_text(text, reply_markup=admin_plan_detail_kb(plan), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("admin:plan:enable:"))
async def enable_plan(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    await _set_plan_active(callback, session, db_user, True)


@router.callback_query(F.data.startswith("admin:plan:disable:"))
async def disable_plan(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    await _set_plan_active(callback, session, db_user, False)


async def _set_plan_active(callback: CallbackQuery, session: AsyncSession, db_user: User, active: bool) -> None:
    plan_id = int(callback.data.split(":")[-1])
    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)
    if plan is None:
        await callback.answer("Plan not found.", show_alert=True)
        return

    await plan_repo.set_active(plan, active)
    audit_repo = AuditLogRepository(session)
    await audit_repo.log(
        db_user.id, "plan_enable" if active else "plan_disable", "plan", str(plan.id)
    )

    text = (
        f"📦 <b>{plan.name}</b>\n\n"
        f"{plan.description or '—'}\n\n"
        f"Price: {plan.price_display()}\n"
        f"Duration: {plan.duration_days} days\n"
        f"Status: {'🟢 Active' if plan.is_active else '🔴 Inactive'}"
    )
    await callback.message.edit_text(text, reply_markup=admin_plan_detail_kb(plan), parse_mode="HTML")
    await callback.answer("Updated.")


@router.callback_query(F.data.startswith("admin:plan:delete:"))
async def delete_plan(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    plan_id = int(callback.data.split(":")[-1])
    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)
    if plan is None:
        await callback.answer("Plan not found.", show_alert=True)
        return

    if await plan_repo.has_related_data(plan_id):
        await callback.answer(
            "Cannot delete: this plan has existing subscriptions or payments. "
            "Disable it instead.",
            show_alert=True,
        )
        return

    await plan_repo.delete(plan)
    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "plan_delete", "plan", str(plan_id))

    plans = await plan_repo.list_all()
    await callback.message.edit_text(
        "📦 <b>Subscription Plans</b>\n\nPlan deleted.",
        reply_markup=admin_plans_kb(plans),
        parse_mode="HTML",
    )
    await callback.answer("Deleted.")


@router.callback_query(F.data.startswith("admin:plan:editprice:"))
async def prompt_edit_price(callback: CallbackQuery, state: FSMContext) -> None:
    plan_id = int(callback.data.split(":")[-1])
    await state.set_state(AdminPlanStates.waiting_for_new_price)
    await state.update_data(plan_id=plan_id)
    await callback.message.edit_text(
        "Send the new price as a number (e.g. 9.99).",
        reply_markup=admin_back_kb(f"admin:plan:view:{plan_id}"),
    )
    await callback.answer()


@router.message(AdminPlanStates.waiting_for_new_price)
async def handle_new_price(message: Message, state: FSMContext, session: AsyncSession, db_user: User) -> None:
    data = await state.get_data()
    plan_id = data.get("plan_id")
    await state.clear()

    try:
        new_price = float(message.text.strip().replace(",", "."))
        if new_price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("Invalid price. Please try again from the plan menu.")
        return

    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)
    if plan is None:
        await message.answer("Plan not found.")
        return

    await plan_repo.update(plan, price=new_price)
    audit_repo = AuditLogRepository(session)
    await audit_repo.log(
        db_user.id, "plan_edit_price", "plan", str(plan.id), details=f"new_price={new_price}"
    )

    await message.answer(f"✅ Price updated to {plan.price_display()}.")


@router.callback_query(F.data == "admin:plan:create")
async def start_create_plan(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPlanStates.waiting_for_name)
    await callback.message.edit_text(
        "Send the new plan's name (e.g. 'VIP 30 Days').",
        reply_markup=admin_back_kb("admin:plans"),
    )
    await callback.answer()


@router.message(AdminPlanStates.waiting_for_name)
async def handle_plan_name(message: Message, state: FSMContext) -> None:
    await state.update_data(name=message.text.strip())
    await state.set_state(AdminPlanStates.waiting_for_description)
    await message.answer("Send the plan's description.")


@router.message(AdminPlanStates.waiting_for_description)
async def handle_plan_description(message: Message, state: FSMContext) -> None:
    await state.update_data(description=message.text.strip())
    await state.set_state(AdminPlanStates.waiting_for_price)
    await message.answer("Send the plan's price as a number (e.g. 9.99).")


@router.message(AdminPlanStates.waiting_for_price)
async def handle_plan_price(message: Message, state: FSMContext) -> None:
    try:
        price = float(message.text.strip().replace(",", "."))
        if price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("Invalid price. Please send a positive number.")
        return

    await state.update_data(price=price)
    await state.set_state(AdminPlanStates.waiting_for_currency)
    await message.answer("Send the currency code (e.g. USD).")


@router.message(AdminPlanStates.waiting_for_currency)
async def handle_plan_currency(message: Message, state: FSMContext) -> None:
    currency = message.text.strip().upper()
    if not (2 <= len(currency) <= 8):
        await message.answer("Please send a valid currency code (2-8 letters).")
        return

    await state.update_data(currency=currency)
    await state.set_state(AdminPlanStates.waiting_for_duration)
    await message.answer("Send the plan duration in days (whole number).")


@router.message(AdminPlanStates.waiting_for_duration)
async def handle_plan_duration(message: Message, state: FSMContext, session: AsyncSession, db_user: User) -> None:
    if not message.text.strip().isdigit():
        await message.answer("Please send a valid whole number of days.")
        return

    duration_days = int(message.text.strip())
    if duration_days <= 0:
        await message.answer("Duration must be a positive number of days.")
        return

    data = await state.get_data()
    await state.clear()

    plan_repo = PlanRepository(session)
    plan = await plan_repo.create(
        name=data["name"],
        description=data["description"],
        price=data["price"],
        currency=data["currency"],
        duration_days=duration_days,
    )

    audit_repo = AuditLogRepository(session)
    await audit_repo.log(db_user.id, "plan_create", "plan", str(plan.id))

    await message.answer(f"✅ Plan '{plan.name}' created ({plan.price_display()}, {plan.duration_days} days).")
