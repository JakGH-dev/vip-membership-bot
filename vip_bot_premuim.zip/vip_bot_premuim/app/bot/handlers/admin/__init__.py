from aiogram import Router

from app.bot.handlers.admin import broadcast, dashboard, plans, promo, settings, subscriptions, users

admin_router = Router(name="admin_root")
admin_router.include_router(dashboard.router)
admin_router.include_router(users.router)
admin_router.include_router(subscriptions.router)
admin_router.include_router(plans.router)
admin_router.include_router(promo.router)
admin_router.include_router(settings.router)
admin_router.include_router(broadcast.router)

__all__ = ["admin_router"]
