from __future__ import annotations

from aiogram import Router
from aiogram.filters import CommandObject, CommandStart
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.user_kb import main_menu_kb
from app.config.logging_config import get_logger
from app.config.settings import Settings, get_settings
from app.database.models.user import User
from app.database.repositories.user_repo import UserRepository
from app.services.referral_service import ReferralService

logger = get_logger(__name__)
router = Router(name="start")

WELCOME_TEXT = (
    "👋 Welcome to VIP Access!\n\n"
    "Here you can subscribe to our VIP plans, manage your membership, "
    "and get access to our private VIP channel.\n\n"
    "Use the menu below to get started."
)


@router.message(CommandStart(deep_link=True))
async def handle_start_with_payload(
    message: Message,
    command: CommandObject,
    session: AsyncSession,
    db_user: User,
) -> None:
    payload = command.args or ""
    if payload.startswith("ref_"):
        referral_code = payload.removeprefix("ref_")
        await _process_referral(session, referral_code, db_user)

    await message.answer(WELCOME_TEXT, reply_markup=main_menu_kb(is_admin=db_user.is_admin))


@router.message(CommandStart())
async def handle_start(message: Message, db_user: User) -> None:
    await message.answer(WELCOME_TEXT, reply_markup=main_menu_kb(is_admin=db_user.is_admin))


async def _process_referral(session: AsyncSession, referral_code: str, new_user: User) -> None:
    user_repo = UserRepository(session)
    referrer = await user_repo.get_by_referral_code(referral_code)
    if referrer is None:
        return

    settings: Settings = get_settings()
    referral_service = ReferralService(session, settings)
    referral = await referral_service.register_referral(referrer, new_user)
    if referral is not None:
        await referral_service.grant_signup_reward_if_eligible(referral)
        logger.info(
            "referral_registered",
            referrer_id=referrer.id,
            new_user_id=new_user.id,
        )
