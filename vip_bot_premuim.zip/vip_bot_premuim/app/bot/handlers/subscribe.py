from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.user_kb import back_home_kb, cancel_kb, plan_confirm_kb, plans_kb
from app.bot.states.admin_states import SubscribeStates
from app.config.settings import Settings, get_settings
from app.database.models.user import User
from app.database.repositories.plan_repo import PlanRepository
from app.services.payment_providers.telegram_payments import TelegramPaymentsProvider
from app.services.payment_service import PaymentService, PaymentValidationError
from app.services.promo_service import PromoApplicationError

router = Router(name="subscribe")


@router.callback_query(F.data.in_({"menu:subscribe", "subscribe:renew"}))
async def show_plans(callback: CallbackQuery, session: AsyncSession) -> None:
    plan_repo = PlanRepository(session)
    plans = await plan_repo.list_active()

    if not plans:
        await callback.answer("No plans are available right now.", show_alert=True)
        return

    await callback.message.edit_text(
        "💎 <b>Choose a VIP Plan</b>\n\nSelect a plan below to see details and pay.",
        reply_markup=plans_kb(plans),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("subscribe:plan:"))
async def show_plan_detail(callback: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    plan_id = int(callback.data.split(":")[-1])
    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)

    if plan is None or not plan.is_active:
        await callback.answer("This plan is no longer available.", show_alert=True)
        return

    await state.update_data(selected_plan_id=plan.id, promo_code=None)

    text = (
        f"📦 <b>{plan.name}</b>\n\n"
        f"{plan.description or 'VIP membership access.'}\n\n"
        f"Duration: {plan.duration_days} days\n"
        f"Price: {plan.price_display()}"
    )
    await callback.message.edit_text(text, reply_markup=plan_confirm_kb(plan.id), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "subscribe:promo")
async def ask_promo_code(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(SubscribeStates.waiting_for_promo_code)
    await callback.message.edit_text(
        "🎟 Send your promo code as a text message, or press Cancel.",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


@router.message(SubscribeStates.waiting_for_promo_code)
async def receive_promo_code(message: Message, state: FSMContext, session: AsyncSession, db_user: User) -> None:
    data = await state.get_data()
    plan_id = data.get("selected_plan_id")
    if plan_id is None:
        await state.clear()
        await message.answer("Please choose a plan again from the menu.")
        return

    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)
    if plan is None:
        await state.clear()
        await message.answer("That plan is no longer available.")
        return

    settings: Settings = get_settings()
    provider = TelegramPaymentsProvider(settings.telegram_payments_provider_token)
    payment_service = PaymentService(session, settings, provider)

    try:
        quote = await payment_service.quote_price(plan, db_user.id, message.text.strip())
    except PromoApplicationError as exc:
        await message.answer(f"❌ {exc}\n\nTry another code or press Cancel.", reply_markup=cancel_kb())
        return

    await state.update_data(promo_code=message.text.strip())
    await state.set_state(None)

    text = (
        f"📦 <b>{plan.name}</b>\n\n"
        f"Base price: {quote.base_price:.2f} {quote.currency}\n"
        f"Discount: -{quote.discount:.2f} {quote.currency}\n"
        f"<b>Total: {quote.final_price:.2f} {quote.currency}</b>"
    )
    await message.answer(text, reply_markup=plan_confirm_kb(plan.id), parse_mode="HTML")


@router.callback_query(F.data.startswith("subscribe:pay:"))
async def start_payment(callback: CallbackQuery, session: AsyncSession, state: FSMContext, db_user: User) -> None:
    plan_id = int(callback.data.split(":")[-1])
    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(plan_id)

    if plan is None or not plan.is_active:
        await callback.answer("This plan is no longer available.", show_alert=True)
        return

    data = await state.get_data()
    promo_code = data.get("promo_code") if data.get("selected_plan_id") == plan_id else None

    settings: Settings = get_settings()
    provider = TelegramPaymentsProvider(settings.telegram_payments_provider_token)
    payment_service = PaymentService(session, settings, provider)

    try:
        await payment_service.create_pending_payment_and_invoice(
            bot=callback.bot,
            chat_id=callback.from_user.id,
            user_id=db_user.id,
            plan=plan,
            promo_code=promo_code,
        )
    except PaymentValidationError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    except PromoApplicationError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    await state.clear()
    await callback.answer("Invoice sent below 👇")
