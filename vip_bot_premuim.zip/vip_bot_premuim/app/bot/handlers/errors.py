from __future__ import annotations

from aiogram import Router
from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
)
from aiogram.types import ErrorEvent
from sqlalchemy.exc import SQLAlchemyError

from app.config.logging_config import get_logger

logger = get_logger(__name__)
router = Router(name="errors")


@router.errors()
async def handle_errors(event: ErrorEvent) -> bool:
    exception = event.exception
    update = event.update

    if isinstance(exception, TelegramRetryAfter):
        logger.warning("telegram_flood_control", retry_after=exception.retry_after)
        return True

    if isinstance(exception, TelegramForbiddenError):
        logger.info("telegram_forbidden", details=str(exception))
        return True

    if isinstance(exception, TelegramBadRequest):
        logger.warning("telegram_bad_request", details=str(exception))
        return True

    if isinstance(exception, TelegramNetworkError):
        logger.warning("telegram_network_error", details=str(exception))
        return True

    if isinstance(exception, TelegramAPIError):
        logger.error("telegram_api_error", details=str(exception))
        return True

    if isinstance(exception, SQLAlchemyError):
        logger.error("database_error", details=str(exception))
        return True

    logger.exception("unhandled_exception", update_id=getattr(update, "update_id", None))
    return True
