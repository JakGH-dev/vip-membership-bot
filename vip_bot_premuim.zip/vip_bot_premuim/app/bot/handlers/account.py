from __future__ import annotations

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.user_kb import account_kb, back_home_kb, settings_kb
from app.config.settings import Settings, get_settings
from app.database.models.user import User
from app.database.repositories.payment_repo import PaymentRepository
from app.database.repositories.subscription_repo import SubscriptionRepository
from app.services.referral_service import ReferralService
from app.services.subscription_service import SubscriptionService
from app.services.vip_channel_service import VipChannelService
from app.utils.datetime_utils import format_datetime, format_remaining, utcnow

router = Router(name="account")


@router.callback_query(F.data == "menu:account")
async def show_account(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(db_user.id)
    payment_repo = PaymentRepository(session)
    total_payments = await payment_repo.list_for_user(db_user.id, limit=1000)

    lines = [
        "👤 <b>My Account</b>",
        f"Name: {db_user.full_name()}",
        f"Username: @{db_user.username}" if db_user.username else "Username: —",
        "",
    ]

    if subscription is not None:
        now = utcnow()
        lines += [
            "VIP status: ✅ Active",
            f"Current plan: {subscription.plan.name}",
            f"Start date: {format_datetime(subscription.starts_at)}",
            f"Expiration date: {format_datetime(subscription.expires_at)}",
            f"Remaining time: {format_remaining(subscription.remaining_seconds(now))}",
            f"Auto-renew: {'On' if subscription.auto_renew else 'Off'}",
        ]
    else:
        lines += ["VIP status: ❌ Not subscribed"]

    lines += ["", f"Total payments: {len(total_payments)}"]

    await callback.message.edit_text(
        "\n".join(lines), reply_markup=account_kb(), parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "account:vip_link")
async def get_vip_link(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    settings: Settings = get_settings()
    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(db_user.id)

    if subscription is None:
        await callback.answer("You don't have an active VIP subscription.", show_alert=True)
        return

    vip_channel_service = VipChannelService(session, callback.bot, settings)
    try:
        link = await vip_channel_service.get_or_create_invite_link(subscription)
    except TelegramBadRequest:
        await callback.answer(
            "Could not generate an invite link right now. Please contact support.",
            show_alert=True,
        )
        return

    await callback.message.answer(
        f"🔗 Your personal VIP invite link (single-use, expires soon):\n{link}"
    )
    await callback.answer()


@router.callback_query(F.data == "menu:payments")
async def show_payment_history(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    payment_repo = PaymentRepository(session)
    payments = await payment_repo.list_for_user(db_user.id, limit=15)

    if not payments:
        text = "💳 <b>Payment History</b>\n\nYou have no payments yet."
    else:
        lines = ["💳 <b>Payment History</b>", ""]
        for payment in payments:
            lines.append(
                f"#{payment.id} • {payment.amount} {payment.currency} • "
                f"{payment.status} • {format_datetime(payment.created_at)}"
            )
        text = "\n".join(lines)

    await callback.message.edit_text(text, reply_markup=back_home_kb("menu:account"), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "menu:referral")
async def show_referral(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    settings: Settings = get_settings()
    referral_service = ReferralService(session, settings)
    stats = await referral_service.get_stats(db_user.id)
    reward_days = await referral_service.resolve_reward_days()

    bot_info = await callback.bot.get_me()
    link = f"https://t.me/{bot_info.username}?start=ref_{db_user.referral_code}"

    text = (
        "🎁 <b>Referral Program</b>\n\n"
        f"Your referral link:\n{link}\n\n"
        f"Total referrals: {stats['total_referrals']}\n"
        f"VIP days earned: {stats['rewarded_days']}\n\n"
        f"You earn {reward_days} VIP day(s) for every friend who joins "
        "using your link."
    )
    await callback.message.edit_text(text, reply_markup=back_home_kb("menu:account"), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "menu:settings")
async def show_settings(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(db_user.id)
    auto_renew = subscription.auto_renew if subscription else False

    text = (
        "⚙️ <b>Settings</b>\n\n"
        "Auto-renew charges you automatically for the same plan when your "
        "subscription is about to expire (requires an active subscription)."
    )
    await callback.message.edit_text(text, reply_markup=settings_kb(auto_renew), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.in_({"settings:auto_renew:on", "settings:auto_renew:off"}))
async def toggle_auto_renew(callback: CallbackQuery, session: AsyncSession, db_user: User) -> None:
    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(db_user.id)

    if subscription is None:
        await callback.answer("You need an active subscription first.", show_alert=True)
        return

    if callback.data.endswith(":on"):
        await subscription_service.enable_auto_renew(subscription)
        await callback.answer("Auto-renew enabled.")
    else:
        await subscription_service.cancel_auto_renew(subscription)
        await callback.answer("Auto-renew disabled.")

    await callback.message.edit_reply_markup(reply_markup=settings_kb(subscription.auto_renew))
