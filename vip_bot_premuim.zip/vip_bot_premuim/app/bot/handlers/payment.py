from __future__ import annotations

from aiogram import Router
from aiogram.types import Message, PreCheckoutQuery
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.user_kb import main_menu_kb
from app.config.logging_config import get_logger
from app.config.settings import Settings, get_settings
from app.database.models.user import User
from app.database.repositories.payment_repo import DuplicatePaymentError, PaymentRepository
from app.database.repositories.plan_repo import PlanRepository
from app.services.payment_providers.telegram_payments import TelegramPaymentsProvider
from app.services.payment_service import PaymentService, PaymentValidationError
from app.services.vip_channel_service import VipChannelService

logger = get_logger(__name__)
router = Router(name="payment")


@router.pre_checkout_query()
async def handle_pre_checkout(pre_checkout_query: PreCheckoutQuery, session: AsyncSession) -> None:
    """Telegram calls this right before charging the user's card. We must
    answer within 10 seconds; answering False cancels the charge cleanly."""
    payment_repo = PaymentRepository(session)
    payment = await payment_repo.get_by_invoice_payload(pre_checkout_query.invoice_payload)

    if payment is None:
        await pre_checkout_query.answer(
            ok=False, error_message="This order could not be found. Please start over."
        )
        return

    if payment.is_final():
        await pre_checkout_query.answer(
            ok=False, error_message="This order has already been processed."
        )
        return

    expected_amount = int(round(float(payment.amount) * 100))
    if pre_checkout_query.total_amount != expected_amount or pre_checkout_query.currency != payment.currency:
        logger.warning(
            "pre_checkout_amount_mismatch",
            payment_id=payment.id,
            expected=expected_amount,
            received=pre_checkout_query.total_amount,
        )
        await pre_checkout_query.answer(
            ok=False, error_message="Order amount mismatch. Please start over."
        )
        return

    plan_repo = PlanRepository(session)
    plan = await plan_repo.get_by_id(payment.plan_id)
    if plan is None or not plan.is_active:
        await pre_checkout_query.answer(
            ok=False, error_message="This plan is no longer available."
        )
        return

    await pre_checkout_query.answer(ok=True)


@router.message(lambda message: message.successful_payment is not None)
async def handle_successful_payment(message: Message, session: AsyncSession, db_user: User) -> None:
    """This handler only fires on Telegram's own `successful_payment`
    field, which Telegram attaches to the message itself after the payment
    provider has approved the charge - never on a user's claim in text."""
    successful_payment = message.successful_payment
    settings: Settings = get_settings()
    provider = TelegramPaymentsProvider(settings.telegram_payments_provider_token)
    payment_service = PaymentService(session, settings, provider)

    provider_update = {
        "telegram_payment_charge_id": successful_payment.telegram_payment_charge_id,
        "provider_payment_charge_id": successful_payment.provider_payment_charge_id,
    }

    try:
        payment = await payment_service.confirm_payment_from_provider(
            invoice_payload=successful_payment.invoice_payload,
            provider_update=provider_update,
        )
    except DuplicatePaymentError:
        logger.error(
            "duplicate_payment_confirmation_blocked",
            invoice_payload=successful_payment.invoice_payload,
            telegram_id=message.from_user.id,
        )
        await message.answer(
            "⚠️ This payment was already processed previously. If you believe "
            "this is an error, please contact support with your receipt."
        )
        return
    except PaymentValidationError as exc:
        logger.error(
            "payment_confirmation_failed",
            invoice_payload=successful_payment.invoice_payload,
            error=str(exc),
        )
        await message.answer(
            "⚠️ We received your payment but could not automatically activate "
            "your subscription. Please contact support with your receipt."
        )
        return

    vip_channel_service = VipChannelService(session, message.bot, settings)
    from app.services.subscription_service import SubscriptionService

    subscription_service = SubscriptionService(session)
    subscription = await subscription_service.get_active_subscription(db_user.id)

    invite_link_text = ""
    if subscription is not None:
        try:
            link = await vip_channel_service.get_or_create_invite_link(subscription)
            invite_link_text = f"\n\n🔗 Your VIP access link:\n{link}"
        except Exception as exc:  # noqa: BLE001 - never fail the confirmation on link errors
            logger.error("vip_invite_link_generation_failed", error=str(exc))
            invite_link_text = (
                "\n\nWe could not generate your VIP invite link automatically. "
                "Use '🔗 VIP Access' in your account menu to retry."
            )

    await message.answer(
        f"✅ Payment confirmed! Your VIP subscription is now active."
        f"{invite_link_text}",
        reply_markup=main_menu_kb(is_admin=db_user.is_admin),
    )
