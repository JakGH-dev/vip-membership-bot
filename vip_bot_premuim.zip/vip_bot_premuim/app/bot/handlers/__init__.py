from aiogram import Router

from app.bot.handlers import account, errors, menu, payment, start, subscribe
from app.bot.handlers.admin import admin_router


def build_root_router() -> Router:
    """Assembles every feature router into one root router in the order
    that gives the most specific handlers (payments, admin) priority over
    the generic ones (menu navigation)."""
    root = Router(name="root")

    # Payment confirmation handlers must be registered early so that
    # pre_checkout_query / successful_payment updates are never accidentally
    # swallowed by a more generic message handler.
    root.include_router(payment.router)
    root.include_router(start.router)
    root.include_router(admin_router)
    root.include_router(menu.router)
    root.include_router(account.router)
    root.include_router(subscribe.router)

    return root


__all__ = ["build_root_router", "errors"]
