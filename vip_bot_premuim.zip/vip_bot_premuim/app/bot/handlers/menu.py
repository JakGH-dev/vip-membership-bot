from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from app.bot.handlers.start import WELCOME_TEXT
from app.bot.keyboards.user_kb import main_menu_kb
from app.database.models.user import User

router = Router(name="menu")


@router.callback_query(F.data == "menu:home")
async def go_home(callback: CallbackQuery, state: FSMContext, db_user: User) -> None:
    await state.clear()
    await callback.message.edit_text(WELCOME_TEXT, reply_markup=main_menu_kb(is_admin=db_user.is_admin))
    await callback.answer()
