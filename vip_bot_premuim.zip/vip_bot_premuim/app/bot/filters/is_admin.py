from __future__ import annotations

from typing import Any

from aiogram.filters import BaseFilter
from aiogram.types import TelegramObject


class IsAdmin(BaseFilter):
    async def __call__(self, event: TelegramObject, db_user: Any = None) -> bool:
        return bool(db_user is not None and db_user.is_admin and not db_user.is_suspended)
