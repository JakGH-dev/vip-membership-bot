from __future__ import annotations

from typing import Sequence

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.database.models.plan import SubscriptionPlan


def main_menu_kb(is_admin: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="👤 My Account", callback_data="menu:account")],
        [InlineKeyboardButton(text="💎 Subscribe", callback_data="menu:subscribe")],
        [
            InlineKeyboardButton(text="💳 Payment History", callback_data="menu:payments"),
            InlineKeyboardButton(text="🎁 Referral", callback_data="menu:referral"),
        ],
        [InlineKeyboardButton(text="⚙️ Settings", callback_data="menu:settings")],
    ]
    if is_admin:
        rows.append([InlineKeyboardButton(text="🛠 Admin Panel", callback_data="admin:open")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_home_kb(back_callback: str | None = None) -> InlineKeyboardMarkup:
    row = []
    if back_callback:
        row.append(InlineKeyboardButton(text="⬅️ Back", callback_data=back_callback))
    row.append(InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home"))
    return InlineKeyboardMarkup(inline_keyboard=[row])


def plans_kb(plans: Sequence[SubscriptionPlan]) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"{plan.name} — {plan.price_display()}",
                callback_data=f"subscribe:plan:{plan.id}",
            )
        ]
        for plan in plans
    ]
    rows.append([InlineKeyboardButton(text="🎟 Have a promo code?", callback_data="subscribe:promo")])
    rows.append(
        [
            InlineKeyboardButton(text="⬅️ Back", callback_data="menu:home"),
            InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home"),
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def plan_confirm_kb(plan_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💳 Pay now", callback_data=f"subscribe:pay:{plan_id}")],
            [
                InlineKeyboardButton(text="⬅️ Back", callback_data="menu:subscribe"),
                InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home"),
            ],
        ]
    )


def account_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💎 Subscribe", callback_data="menu:subscribe"),
                InlineKeyboardButton(text="🔄 Renew", callback_data="subscribe:renew"),
            ],
            [
                InlineKeyboardButton(text="⬆️ Upgrade", callback_data="menu:subscribe"),
                InlineKeyboardButton(text="🔗 VIP Access", callback_data="account:vip_link"),
            ],
            [
                InlineKeyboardButton(text="💳 Payment History", callback_data="menu:payments"),
                InlineKeyboardButton(text="🎁 Referral", callback_data="menu:referral"),
            ],
            [InlineKeyboardButton(text="⚙️ Settings", callback_data="menu:settings")],
            [InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")],
        ]
    )


def settings_kb(auto_renew_enabled: bool) -> InlineKeyboardMarkup:
    toggle_text = "🔕 Disable Auto-Renew" if auto_renew_enabled else "🔔 Enable Auto-Renew"
    toggle_callback = "settings:auto_renew:off" if auto_renew_enabled else "settings:auto_renew:on"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_callback)],
            [
                InlineKeyboardButton(text="⬅️ Back", callback_data="menu:account"),
                InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home"),
            ],
        ]
    )


def cancel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Cancel", callback_data="menu:home")]]
    )
