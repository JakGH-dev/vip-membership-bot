from __future__ import annotations

from typing import Sequence

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.database.models.plan import SubscriptionPlan
from app.database.models.promo import PromoCode


def admin_home_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="📊 Dashboard", callback_data="admin:dashboard")],
        [
            InlineKeyboardButton(text="👥 Users", callback_data="admin:users"),
            InlineKeyboardButton(text="💎 Subscriptions", callback_data="admin:subs"),
        ],
        [
            InlineKeyboardButton(text="💳 Payments", callback_data="admin:payments"),
            InlineKeyboardButton(text="📦 Plans", callback_data="admin:plans"),
        ],
        [
            InlineKeyboardButton(text="🎟 Promo Codes", callback_data="admin:promos"),
            InlineKeyboardButton(text="🎁 Referrals", callback_data="admin:referrals"),
        ],
        [
            InlineKeyboardButton(text="📢 Broadcast", callback_data="admin:broadcast"),
            InlineKeyboardButton(text="⚙️ Settings", callback_data="admin:settings"),
        ],
        [InlineKeyboardButton(text="📋 Logs", callback_data="admin:logs")],
        [InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_back_kb(back_callback: str = "admin:open") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="⬅️ Back", callback_data=back_callback),
                InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home"),
            ]
        ]
    )


def admin_user_actions_kb(user_id: int, is_suspended: bool) -> InlineKeyboardMarkup:
    suspend_text = "✅ Unsuspend" if is_suspended else "🚫 Suspend"
    suspend_cb = f"admin:user:unsuspend:{user_id}" if is_suspended else f"admin:user:suspend:{user_id}"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="➕ Add VIP days", callback_data=f"admin:user:adddays:{user_id}")],
            [InlineKeyboardButton(text="🗑 Remove VIP", callback_data=f"admin:user:removevip:{user_id}")],
            [InlineKeyboardButton(text=suspend_text, callback_data=suspend_cb)],
            [InlineKeyboardButton(text="💳 Payment history", callback_data=f"admin:user:payments:{user_id}")],
            [InlineKeyboardButton(text="⬅️ Back", callback_data="admin:users"), InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")],
        ]
    )


def admin_plans_kb(plans: Sequence[SubscriptionPlan]) -> InlineKeyboardMarkup:
    rows = []
    for plan in plans:
        status_icon = "🟢" if plan.is_active else "🔴"
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{status_icon} {plan.name} ({plan.price_display()})",
                    callback_data=f"admin:plan:view:{plan.id}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="➕ Create Plan", callback_data="admin:plan:create")])
    rows.append([InlineKeyboardButton(text="⬅️ Back", callback_data="admin:open"), InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_plan_detail_kb(plan: SubscriptionPlan) -> InlineKeyboardMarkup:
    toggle_text = "🔴 Disable" if plan.is_active else "🟢 Enable"
    toggle_cb = f"admin:plan:disable:{plan.id}" if plan.is_active else f"admin:plan:enable:{plan.id}"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✏️ Edit price", callback_data=f"admin:plan:editprice:{plan.id}")],
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_cb)],
            [InlineKeyboardButton(text="🗑 Delete", callback_data=f"admin:plan:delete:{plan.id}")],
            [InlineKeyboardButton(text="⬅️ Back", callback_data="admin:plans"), InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")],
        ]
    )


def admin_promos_kb(promos: Sequence[PromoCode]) -> InlineKeyboardMarkup:
    rows = []
    for promo in promos:
        status_icon = "🟢" if promo.is_active else "🔴"
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{status_icon} {promo.code}",
                    callback_data=f"admin:promo:view:{promo.id}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="➕ Create Promo Code", callback_data="admin:promo:create")])
    rows.append([InlineKeyboardButton(text="⬅️ Back", callback_data="admin:open"), InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_promo_detail_kb(promo: PromoCode) -> InlineKeyboardMarkup:
    toggle_text = "🔴 Disable" if promo.is_active else "🟢 Enable"
    toggle_cb = f"admin:promo:disable:{promo.id}" if promo.is_active else f"admin:promo:enable:{promo.id}"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_cb)],
            [InlineKeyboardButton(text="⬅️ Back", callback_data="admin:promos"), InlineKeyboardButton(text="🏠 Main Menu", callback_data="menu:home")],
        ]
    )


def admin_broadcast_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Send", callback_data="admin:broadcast:confirm"),
                InlineKeyboardButton(text="❌ Cancel", callback_data="admin:open"),
            ]
        ]
    )


def admin_cancel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Cancel", callback_data="admin:open")]]
    )
