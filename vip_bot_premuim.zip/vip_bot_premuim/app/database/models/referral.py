from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import BigInteger, ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin


class ReferralRewardType(str, enum.Enum):
    VIP_DAYS = "vip_days"
    COMMISSION_PERCENT = "commission_percent"


class Referral(TimestampMixin, Base):
    __tablename__ = "referrals"
    __table_args__ = ()

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    referrer_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    referred_user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, index=True
    )

    referrer: Mapped["User"] = relationship(
        back_populates="referrals_made", foreign_keys=[referrer_id]
    )
    referred_user: Mapped["User"] = relationship(foreign_keys=[referred_user_id])


class ReferralReward(TimestampMixin, Base):
    __tablename__ = "referral_rewards"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    referrer_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    referral_id: Mapped[int] = mapped_column(ForeignKey("referrals.id", ondelete="CASCADE"))
    payment_id: Mapped[Optional[int]] = mapped_column(ForeignKey("payments.id"), nullable=True)

    reward_type: Mapped[ReferralRewardType] = mapped_column(String(32), nullable=False)
    reward_value: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    applied: Mapped[bool] = mapped_column(default=False, nullable=False)

    referrer: Mapped["User"] = relationship(back_populates="referral_rewards")
