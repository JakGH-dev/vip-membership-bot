from __future__ import annotations

import enum
from datetime import datetime
from typing import List, Optional

from sqlalchemy import DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin


class PromoDiscountType(str, enum.Enum):
    PERCENT = "percent"
    FIXED = "fixed"


class PromoCode(TimestampMixin, Base):
    __tablename__ = "promo_codes"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True, nullable=False)
    discount_type: Mapped[PromoDiscountType] = mapped_column(String(16), nullable=False)
    discount_value: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)

    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    valid_until: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    max_uses_total: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    max_uses_per_user: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    used_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Comma separated plan ids this code applies to; empty string means all plans.
    applicable_plan_ids: Mapped[str] = mapped_column(Text, default="", nullable=False)

    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)

    usages: Mapped[List["PromoCodeUsage"]] = relationship(
        back_populates="promo_code", cascade="all, delete-orphan"
    )

    def applies_to_plan(self, plan_id: int) -> bool:
        if not self.applicable_plan_ids.strip():
            return True
        ids = {int(p.strip()) for p in self.applicable_plan_ids.split(",") if p.strip()}
        return plan_id in ids

    def is_within_validity(self, now: datetime) -> bool:
        return self.valid_from <= now <= self.valid_until

    def has_remaining_total_uses(self) -> bool:
        if self.max_uses_total is None:
            return True
        return self.used_count < self.max_uses_total

    def compute_discount(self, price: float) -> float:
        if self.discount_type == PromoDiscountType.PERCENT:
            discount = float(price) * (float(self.discount_value) / 100.0)
        else:
            discount = float(self.discount_value)
        return max(0.0, min(discount, float(price)))


class PromoCodeUsage(TimestampMixin, Base):
    __tablename__ = "promo_code_usages"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    promo_code_id: Mapped[int] = mapped_column(
        ForeignKey("promo_codes.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id"), nullable=False)

    promo_code: Mapped["PromoCode"] = relationship(back_populates="usages")
    user: Mapped["User"] = relationship(back_populates="promo_usages")
