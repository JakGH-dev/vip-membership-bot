from __future__ import annotations

import enum
from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, DateTime, Enum, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin
from app.database.models.payment import Payment
from app.database.models.plan import SubscriptionPlan
from app.database.models.user import User


class SubscriptionStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    SUSPENDED = "suspended"


class Subscription(TimestampMixin, Base):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("subscription_plans.id"), index=True)
    payment_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("payments.id"), nullable=True
    )

    status: Mapped[SubscriptionStatus] = mapped_column(
        Enum(SubscriptionStatus, name="subscription_status", values_callable=lambda x: [e.value for e in x]),
        default=SubscriptionStatus.ACTIVE,
        nullable=False,
        index=True,
    )

    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)

    auto_renew: Mapped[bool] = mapped_column(default=False, nullable=False)

    vip_invite_link: Mapped[Optional[str]] = mapped_column(nullable=True)

    notified_thresholds_minutes: Mapped[str] = mapped_column(
        default="", nullable=False
    )  # comma-separated minutes already notified, to prevent duplicate notifications

    telegram_chat_member_status: Mapped[Optional[str]] = mapped_column(nullable=True)

    user: Mapped["User"] = relationship(back_populates="subscriptions")
    plan: Mapped["SubscriptionPlan"] = relationship(back_populates="subscriptions")
    payment: Mapped[Optional["Payment"]] = relationship()

    def is_currently_active(self, now: datetime) -> bool:
        return self.status == SubscriptionStatus.ACTIVE and self.expires_at > now

    def remaining_seconds(self, now: datetime) -> float:
        delta = (self.expires_at - now).total_seconds()
        return max(delta, 0.0)
