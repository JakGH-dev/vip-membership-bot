from __future__ import annotations

import enum
from typing import Optional

from sqlalchemy import ForeignKey, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    EXPIRED = "expired"


class PaymentProviderName(str, enum.Enum):
    TELEGRAM = "telegram"
    STRIPE = "stripe"
    MANUAL = "manual"


class Payment(TimestampMixin, Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("subscription_plans.id"), index=True)
    promo_code_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("promo_codes.id"), nullable=True
    )

    provider: Mapped[PaymentProviderName] = mapped_column(
        String(32), default=PaymentProviderName.TELEGRAM, nullable=False
    )

    # Idempotency: unique id from the payment provider, used to reject duplicates.
    provider_payment_id: Mapped[str] = mapped_column(
        String(256), unique=True, index=True, nullable=False
    )
    invoice_payload: Mapped[str] = mapped_column(String(256), unique=True, index=True, nullable=False)

    amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(8), nullable=False)
    discount_amount: Mapped[float] = mapped_column(Numeric(12, 2), default=0, nullable=False)

    status: Mapped[PaymentStatus] = mapped_column(
        String(16), default=PaymentStatus.PENDING, nullable=False, index=True
    )

    user: Mapped["User"] = relationship(back_populates="payments")

    def is_final(self) -> bool:
        return self.status in (
            PaymentStatus.PAID,
            PaymentStatus.FAILED,
            PaymentStatus.CANCELLED,
            PaymentStatus.REFUNDED,
            PaymentStatus.EXPIRED,
        )
