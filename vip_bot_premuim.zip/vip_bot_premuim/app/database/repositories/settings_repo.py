from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.bot_setting import BotSetting


class BotSettingRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self, key: str) -> Optional[BotSetting]:
        return await self.session.get(BotSetting, key)

    async def get_value(self, key: str, default: str = "") -> str:
        setting = await self.get(key)
        return setting.value if setting is not None else default

    async def set(self, key: str, value: str, description: str = "") -> BotSetting:
        setting = await self.get(key)
        if setting is None:
            setting = BotSetting(key=key, value=value, description=description)
            self.session.add(setting)
        else:
            setting.value = value
            if description:
                setting.description = description
        await self.session.flush()
        return setting

    async def list_all(self) -> Sequence[BotSetting]:
        result = await self.session.execute(select(BotSetting).order_by(BotSetting.key))
        return result.scalars().all()
