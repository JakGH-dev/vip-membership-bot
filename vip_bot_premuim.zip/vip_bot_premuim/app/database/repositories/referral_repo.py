from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.referral import Referral, ReferralReward, ReferralRewardType


class ReferralRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_referred_user(self, referred_user_id: int) -> Optional[Referral]:
        result = await self.session.execute(
            select(Referral).where(Referral.referred_user_id == referred_user_id)
        )
        return result.scalar_one_or_none()

    async def create(self, referrer_id: int, referred_user_id: int) -> Referral:
        referral = Referral(referrer_id=referrer_id, referred_user_id=referred_user_id)
        self.session.add(referral)
        await self.session.flush()
        return referral

    async def count_for_referrer(self, referrer_id: int) -> int:
        result = await self.session.execute(
            select(func.count(Referral.id)).where(Referral.referrer_id == referrer_id)
        )
        return int(result.scalar_one())

    async def list_for_referrer(self, referrer_id: int) -> Sequence[Referral]:
        result = await self.session.execute(
            select(Referral).where(Referral.referrer_id == referrer_id)
        )
        return result.scalars().all()

    async def create_reward(
        self,
        referrer_id: int,
        referral_id: int,
        reward_type: ReferralRewardType,
        reward_value: float,
        payment_id: Optional[int] = None,
    ) -> ReferralReward:
        reward = ReferralReward(
            referrer_id=referrer_id,
            referral_id=referral_id,
            reward_type=reward_type,
            reward_value=reward_value,
            payment_id=payment_id,
            applied=False,
        )
        self.session.add(reward)
        await self.session.flush()
        return reward

    async def mark_reward_applied(self, reward: ReferralReward) -> ReferralReward:
        reward.applied = True
        await self.session.flush()
        return reward

    async def sum_rewarded_days(self, referrer_id: int) -> int:
        result = await self.session.execute(
            select(func.coalesce(func.sum(ReferralReward.reward_value), 0)).where(
                ReferralReward.referrer_id == referrer_id,
                ReferralReward.reward_type == ReferralRewardType.VIP_DAYS,
                ReferralReward.applied.is_(True),
            )
        )
        return int(result.scalar_one())
