from __future__ import annotations

from datetime import datetime
from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models.subscription import Subscription, SubscriptionStatus


class SubscriptionRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, subscription_id: int) -> Optional[Subscription]:
        result = await self.session.execute(
            select(Subscription)
            .options(selectinload(Subscription.plan), selectinload(Subscription.user))
            .where(Subscription.id == subscription_id)
        )
        return result.scalar_one_or_none()

    async def get_active_for_user(self, user_id: int, now: datetime) -> Optional[Subscription]:
        result = await self.session.execute(
            select(Subscription)
            .options(selectinload(Subscription.plan))
            .where(
                Subscription.user_id == user_id,
                Subscription.status == SubscriptionStatus.ACTIVE,
                Subscription.expires_at > now,
            )
            .order_by(Subscription.expires_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def list_for_user(self, user_id: int) -> Sequence[Subscription]:
        result = await self.session.execute(
            select(Subscription)
            .options(selectinload(Subscription.plan))
            .where(Subscription.user_id == user_id)
            .order_by(Subscription.created_at.desc())
        )
        return result.scalars().all()

    async def list_expiring_within(
        self, now: datetime, deadline: datetime, min_deadline: datetime
    ) -> Sequence[Subscription]:
        result = await self.session.execute(
            select(Subscription)
            .options(selectinload(Subscription.user), selectinload(Subscription.plan))
            .where(
                Subscription.status == SubscriptionStatus.ACTIVE,
                Subscription.expires_at > now,
                Subscription.expires_at <= deadline,
                Subscription.expires_at > min_deadline,
            )
        )
        return result.scalars().all()

    async def list_expired(self, now: datetime) -> Sequence[Subscription]:
        result = await self.session.execute(
            select(Subscription)
            .options(selectinload(Subscription.user), selectinload(Subscription.plan))
            .where(
                Subscription.status == SubscriptionStatus.ACTIVE,
                Subscription.expires_at <= now,
            )
        )
        return result.scalars().all()

    async def create(
        self,
        user_id: int,
        plan_id: int,
        payment_id: Optional[int],
        starts_at: datetime,
        expires_at: datetime,
        status: SubscriptionStatus = SubscriptionStatus.ACTIVE,
    ) -> Subscription:
        subscription = Subscription(
            user_id=user_id,
            plan_id=plan_id,
            payment_id=payment_id,
            starts_at=starts_at,
            expires_at=expires_at,
            status=status,
        )
        self.session.add(subscription)
        await self.session.flush()
        return subscription

    async def extend(self, subscription: Subscription, new_expires_at: datetime) -> Subscription:
        subscription.expires_at = new_expires_at
        subscription.status = SubscriptionStatus.ACTIVE
        subscription.notified_thresholds_minutes = ""
        await self.session.flush()
        return subscription

    async def set_status(
        self, subscription: Subscription, status: SubscriptionStatus
    ) -> Subscription:
        subscription.status = status
        await self.session.flush()
        return subscription

    async def set_invite_link(self, subscription: Subscription, link: Optional[str]) -> Subscription:
        subscription.vip_invite_link = link
        await self.session.flush()
        return subscription

    async def mark_threshold_notified(
        self, subscription: Subscription, threshold_minutes: int
    ) -> Subscription:
        existing = {
            int(v) for v in subscription.notified_thresholds_minutes.split(",") if v.strip()
        }
        existing.add(threshold_minutes)
        subscription.notified_thresholds_minutes = ",".join(str(v) for v in sorted(existing))
        await self.session.flush()
        return subscription

    def has_threshold_been_notified(
        self, subscription: Subscription, threshold_minutes: int
    ) -> bool:
        existing = {
            int(v) for v in subscription.notified_thresholds_minutes.split(",") if v.strip()
        }
        return threshold_minutes in existing

    async def count_active(self, now: datetime) -> int:
        result = await self.session.execute(
            select(func.count(Subscription.id)).where(
                Subscription.status == SubscriptionStatus.ACTIVE,
                Subscription.expires_at > now,
            )
        )
        return int(result.scalar_one())

    async def count_expired(self) -> int:
        result = await self.session.execute(
            select(func.count(Subscription.id)).where(
                Subscription.status == SubscriptionStatus.EXPIRED
            )
        )
        return int(result.scalar_one())
