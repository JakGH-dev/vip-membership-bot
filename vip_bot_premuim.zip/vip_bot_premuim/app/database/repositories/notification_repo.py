from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.notification_log import NotificationLog


class NotificationLogRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def log(
        self,
        user_id: int,
        subscription_id: int,
        notification_type: str,
        threshold_minutes: int,
        delivered: bool,
    ) -> NotificationLog:
        entry = NotificationLog(
            user_id=user_id,
            subscription_id=subscription_id,
            notification_type=notification_type,
            threshold_minutes=threshold_minutes,
            delivered=delivered,
        )
        self.session.add(entry)
        await self.session.flush()
        return entry
