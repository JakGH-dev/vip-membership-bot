from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.plan import SubscriptionPlan


class PlanRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, plan_id: int) -> Optional[SubscriptionPlan]:
        return await self.session.get(SubscriptionPlan, plan_id)

    async def list_active(self) -> Sequence[SubscriptionPlan]:
        result = await self.session.execute(
            select(SubscriptionPlan)
            .where(SubscriptionPlan.is_active.is_(True))
            .order_by(SubscriptionPlan.sort_order, SubscriptionPlan.duration_days)
        )
        return result.scalars().all()

    async def list_all(self) -> Sequence[SubscriptionPlan]:
        result = await self.session.execute(
            select(SubscriptionPlan).order_by(SubscriptionPlan.sort_order, SubscriptionPlan.id)
        )
        return result.scalars().all()

    async def create(
        self,
        name: str,
        description: str,
        price: float,
        currency: str,
        duration_days: int,
        sort_order: int = 0,
    ) -> SubscriptionPlan:
        plan = SubscriptionPlan(
            name=name,
            description=description,
            price=price,
            currency=currency,
            duration_days=duration_days,
            sort_order=sort_order,
            is_active=True,
        )
        self.session.add(plan)
        await self.session.flush()
        return plan

    async def update(
        self,
        plan: SubscriptionPlan,
        name: Optional[str] = None,
        description: Optional[str] = None,
        price: Optional[float] = None,
        currency: Optional[str] = None,
        duration_days: Optional[int] = None,
        sort_order: Optional[int] = None,
    ) -> SubscriptionPlan:
        if name is not None:
            plan.name = name
        if description is not None:
            plan.description = description
        if price is not None:
            plan.price = price
        if currency is not None:
            plan.currency = currency
        if duration_days is not None:
            plan.duration_days = duration_days
        if sort_order is not None:
            plan.sort_order = sort_order
        await self.session.flush()
        return plan

    async def set_active(self, plan: SubscriptionPlan, active: bool) -> SubscriptionPlan:
        plan.is_active = active
        await self.session.flush()
        return plan

    async def has_related_data(self, plan_id: int) -> bool:
        from app.database.models.payment import Payment
        from app.database.models.subscription import Subscription

        sub_result = await self.session.execute(
            select(Subscription.id).where(Subscription.plan_id == plan_id).limit(1)
        )
        if sub_result.scalar_one_or_none() is not None:
            return True

        pay_result = await self.session.execute(
            select(Payment.id).where(Payment.plan_id == plan_id).limit(1)
        )
        return pay_result.scalar_one_or_none() is not None

    async def delete(self, plan: SubscriptionPlan) -> None:
        await self.session.delete(plan)
        await self.session.flush()
