from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.user import User


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, user_id: int) -> Optional[User]:
        return await self.session.get(User, user_id)

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_by_username(self, username: str) -> Optional[User]:
        clean = username.lstrip("@")
        result = await self.session.execute(
            select(User).where(func.lower(User.username) == clean.lower())
        )
        return result.scalar_one_or_none()

    async def get_by_referral_code(self, code: str) -> Optional[User]:
        result = await self.session.execute(
            select(User).where(User.referral_code == code)
        )
        return result.scalar_one_or_none()

    async def create(
        self,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        language_code: Optional[str],
        referral_code: str,
        is_admin: bool = False,
        referred_by_id: Optional[int] = None,
    ) -> User:
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            language_code=language_code,
            referral_code=referral_code,
            is_admin=is_admin,
            referred_by_id=referred_by_id,
        )
        self.session.add(user)
        await self.session.flush()
        return user

    async def update_profile(
        self,
        user: User,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        language_code: Optional[str],
    ) -> User:
        user.username = username
        user.first_name = first_name
        user.last_name = last_name
        user.language_code = language_code
        await self.session.flush()
        return user

    async def set_suspended(self, user: User, suspended: bool) -> User:
        user.is_suspended = suspended
        await self.session.flush()
        return user

    async def set_bot_blocked(self, user: User, blocked: bool) -> User:
        user.is_bot_blocked = blocked
        await self.session.flush()
        return user

    async def count_total(self) -> int:
        result = await self.session.execute(select(func.count(User.id)))
        return int(result.scalar_one())

    async def count_created_since(self, since) -> int:
        result = await self.session.execute(
            select(func.count(User.id)).where(User.created_at >= since)
        )
        return int(result.scalar_one())

    async def search(self, query: str, limit: int = 20) -> Sequence[User]:
        query = query.strip()
        if query.isdigit():
            result = await self.session.execute(
                select(User).where(User.telegram_id == int(query)).limit(limit)
            )
            return result.scalars().all()

        like_query = f"%{query.lstrip('@').lower()}%"
        result = await self.session.execute(
            select(User)
            .where(func.lower(func.coalesce(User.username, "")).like(like_query))
            .limit(limit)
        )
        return result.scalars().all()
