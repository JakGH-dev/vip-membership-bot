from __future__ import annotations

from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.promo import PromoCode, PromoCodeUsage


class PromoRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, promo_id: int) -> Optional[PromoCode]:
        return await self.session.get(PromoCode, promo_id)

    async def get_by_code(self, code: str) -> Optional[PromoCode]:
        result = await self.session.execute(
            select(PromoCode).where(func.upper(PromoCode.code) == code.upper())
        )
        return result.scalar_one_or_none()

    async def list_all(self) -> Sequence[PromoCode]:
        result = await self.session.execute(
            select(PromoCode).order_by(PromoCode.created_at.desc())
        )
        return result.scalars().all()

    async def create(
        self,
        code: str,
        discount_type,
        discount_value: float,
        valid_from,
        valid_until,
        max_uses_total: Optional[int],
        max_uses_per_user: int,
        applicable_plan_ids: str,
    ) -> PromoCode:
        promo = PromoCode(
            code=code.upper(),
            discount_type=discount_type,
            discount_value=discount_value,
            valid_from=valid_from,
            valid_until=valid_until,
            max_uses_total=max_uses_total,
            max_uses_per_user=max_uses_per_user,
            applicable_plan_ids=applicable_plan_ids,
            is_active=True,
        )
        self.session.add(promo)
        await self.session.flush()
        return promo

    async def set_active(self, promo: PromoCode, active: bool) -> PromoCode:
        promo.is_active = active
        await self.session.flush()
        return promo

    async def increment_usage(self, promo: PromoCode) -> PromoCode:
        promo.used_count += 1
        await self.session.flush()
        return promo

    async def count_user_usages(self, promo_id: int, user_id: int) -> int:
        result = await self.session.execute(
            select(func.count(PromoCodeUsage.id)).where(
                PromoCodeUsage.promo_code_id == promo_id,
                PromoCodeUsage.user_id == user_id,
            )
        )
        return int(result.scalar_one())

    async def record_usage(
        self, promo_id: int, user_id: int, payment_id: int
    ) -> PromoCodeUsage:
        usage = PromoCodeUsage(promo_code_id=promo_id, user_id=user_id, payment_id=payment_id)
        self.session.add(usage)
        await self.session.flush()
        return usage
