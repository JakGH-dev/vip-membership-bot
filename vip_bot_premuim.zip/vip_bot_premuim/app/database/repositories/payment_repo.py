from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional, Sequence

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models.payment import Payment, PaymentProviderName, PaymentStatus


class DuplicatePaymentError(Exception):
    pass


class PaymentRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, payment_id: int) -> Optional[Payment]:
        return await self.session.get(Payment, payment_id)

    async def get_by_provider_payment_id(self, provider_payment_id: str) -> Optional[Payment]:
        result = await self.session.execute(
            select(Payment).where(Payment.provider_payment_id == provider_payment_id)
        )
        return result.scalar_one_or_none()

    async def get_by_invoice_payload(self, invoice_payload: str) -> Optional[Payment]:
        result = await self.session.execute(
            select(Payment).where(Payment.invoice_payload == invoice_payload)
        )
        return result.scalar_one_or_none()

    async def create_pending(
        self,
        user_id: int,
        plan_id: int,
        provider: PaymentProviderName,
        invoice_payload: str,
        pending_reference: str,
        amount: float,
        currency: str,
        discount_amount: float = 0.0,
        promo_code_id: Optional[int] = None,
    ) -> Payment:
        payment = Payment(
            user_id=user_id,
            plan_id=plan_id,
            provider=provider,
            invoice_payload=invoice_payload,
            provider_payment_id=pending_reference,
            amount=amount,
            currency=currency,
            discount_amount=discount_amount,
            promo_code_id=promo_code_id,
            status=PaymentStatus.PENDING,
        )
        self.session.add(payment)
        try:
            await self.session.flush()
        except IntegrityError as exc:
            await self.session.rollback()
            raise DuplicatePaymentError(str(exc)) from exc
        return payment

    async def mark_paid(self, payment: Payment, final_provider_payment_id: str) -> Payment:
        existing = await self.get_by_provider_payment_id(final_provider_payment_id)
        if existing is not None and existing.id != payment.id:
            raise DuplicatePaymentError(
                f"provider_payment_id {final_provider_payment_id} already used"
            )
        payment.provider_payment_id = final_provider_payment_id
        payment.status = PaymentStatus.PAID
        await self.session.flush()
        return payment

    async def mark_status(self, payment: Payment, status: PaymentStatus) -> Payment:
        payment.status = status
        await self.session.flush()
        return payment

    async def list_for_user(self, user_id: int, limit: int = 20) -> Sequence[Payment]:
        result = await self.session.execute(
            select(Payment)
            .where(Payment.user_id == user_id)
            .order_by(Payment.created_at.desc())
            .limit(limit)
        )
        return result.scalars().all()

    async def search(self, query: str, limit: int = 20) -> Sequence[Payment]:
        like_query = f"%{query.lower()}%"
        result = await self.session.execute(
            select(Payment)
            .where(
                func.lower(Payment.provider_payment_id).like(like_query)
                | func.lower(Payment.invoice_payload).like(like_query)
            )
            .order_by(Payment.created_at.desc())
            .limit(limit)
        )
        return result.scalars().all()

    async def sum_amount_since(self, since: datetime) -> float:
        result = await self.session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0)).where(
                Payment.status == PaymentStatus.PAID, Payment.created_at >= since
            )
        )
        return float(result.scalar_one())

    async def sum_amount_total(self) -> float:
        result = await self.session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0)).where(
                Payment.status == PaymentStatus.PAID
            )
        )
        return float(result.scalar_one())

    async def count_paid_total(self) -> int:
        result = await self.session.execute(
            select(func.count(Payment.id)).where(Payment.status == PaymentStatus.PAID)
        )
        return int(result.scalar_one())

    async def count_all_total(self) -> int:
        result = await self.session.execute(select(func.count(Payment.id)))
        return int(result.scalar_one())

    async def list_expired_pending(self, older_than: datetime) -> Sequence[Payment]:
        result = await self.session.execute(
            select(Payment).where(
                Payment.status == PaymentStatus.PENDING,
                Payment.created_at < older_than,
            )
        )
        return result.scalars().all()
