from __future__ import annotations

from datetime import timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.promo import PromoDiscountType
from app.database.repositories.plan_repo import PlanRepository
from app.database.repositories.promo_repo import PromoRepository
from app.database.repositories.user_repo import UserRepository
from app.services.promo_service import PromoApplicationError, PromoService
from app.utils.codes import generate_referral_code
from app.utils.datetime_utils import utcnow


async def _make_user(session: AsyncSession, telegram_id: int = 1):
    user_repo = UserRepository(session)
    return await user_repo.create(
        telegram_id=telegram_id,
        username="tester",
        first_name="Test",
        last_name=None,
        language_code="en",
        referral_code=generate_referral_code(),
    )


async def _make_plan(session: AsyncSession):
    plan_repo = PlanRepository(session)
    return await plan_repo.create(
        name="VIP 30 Days", description="", price=100.0, currency="USD", duration_days=30
    )


async def test_percent_discount_calculation(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    promo_repo = PromoRepository(session)
    now = utcnow()

    promo = await promo_repo.create(
        code="VIP50",
        discount_type=PromoDiscountType.PERCENT,
        discount_value=50,
        valid_from=now - timedelta(days=1),
        valid_until=now + timedelta(days=1),
        max_uses_total=None,
        max_uses_per_user=1,
        applicable_plan_ids="",
    )

    service = PromoService(session)
    validated = await service.validate_and_get("vip50", plan.id, user.id)

    assert validated.id == promo.id
    assert validated.compute_discount(100.0) == 50.0


async def test_expired_promo_is_rejected(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    promo_repo = PromoRepository(session)
    now = utcnow()

    await promo_repo.create(
        code="OLD10",
        discount_type=PromoDiscountType.FIXED,
        discount_value=10,
        valid_from=now - timedelta(days=10),
        valid_until=now - timedelta(days=1),
        max_uses_total=None,
        max_uses_per_user=1,
        applicable_plan_ids="",
    )

    service = PromoService(session)
    with pytest.raises(PromoApplicationError):
        await service.validate_and_get("OLD10", plan.id, user.id)


async def test_promo_restricted_to_other_plan_is_rejected(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    promo_repo = PromoRepository(session)
    now = utcnow()

    await promo_repo.create(
        code="ONLYOTHER",
        discount_type=PromoDiscountType.FIXED,
        discount_value=5,
        valid_from=now - timedelta(days=1),
        valid_until=now + timedelta(days=1),
        max_uses_total=None,
        max_uses_per_user=1,
        applicable_plan_ids=str(plan.id + 999),
    )

    service = PromoService(session)
    with pytest.raises(PromoApplicationError):
        await service.validate_and_get("ONLYOTHER", plan.id, user.id)


async def test_promo_usage_limit_per_user(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    promo_repo = PromoRepository(session)
    now = utcnow()

    promo = await promo_repo.create(
        code="ONEUSE",
        discount_type=PromoDiscountType.FIXED,
        discount_value=5,
        valid_from=now - timedelta(days=1),
        valid_until=now + timedelta(days=1),
        max_uses_total=None,
        max_uses_per_user=1,
        applicable_plan_ids="",
    )
    await promo_repo.record_usage(promo.id, user.id, payment_id=1)

    service = PromoService(session)
    with pytest.raises(PromoApplicationError):
        await service.validate_and_get("ONEUSE", plan.id, user.id)


async def test_promo_total_usage_limit(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    promo_repo = PromoRepository(session)
    now = utcnow()

    promo = await promo_repo.create(
        code="LIMITED",
        discount_type=PromoDiscountType.FIXED,
        discount_value=5,
        valid_from=now - timedelta(days=1),
        valid_until=now + timedelta(days=1),
        max_uses_total=1,
        max_uses_per_user=5,
        applicable_plan_ids="",
    )
    await promo_repo.increment_usage(promo)

    service = PromoService(session)
    with pytest.raises(PromoApplicationError):
        await service.validate_and_get("LIMITED", plan.id, user.id)
