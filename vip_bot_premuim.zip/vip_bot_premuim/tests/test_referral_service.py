from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import Settings
from app.database.repositories.user_repo import UserRepository
from app.services.referral_service import ReferralService
from app.utils.codes import generate_referral_code


def _make_settings(**overrides) -> Settings:
    defaults = dict(
        BOT_TOKEN="123:ABC",
        ADMIN_IDS="1",
        VIP_CHANNEL_ID=-100123,
        TELEGRAM_PAYMENTS_PROVIDER_TOKEN="provider-token",
        DATABASE_URL="sqlite+aiosqlite:///:memory:",
        REDIS_URL="redis://localhost:6379/0",
        REFERRAL_REWARD_DAYS=3,
    )
    defaults.update(overrides)
    return Settings(**defaults)


async def _make_user(session: AsyncSession, telegram_id: int):
    user_repo = UserRepository(session)
    return await user_repo.create(
        telegram_id=telegram_id,
        username=f"user{telegram_id}",
        first_name="Test",
        last_name=None,
        language_code="en",
        referral_code=generate_referral_code(),
    )


async def test_self_referral_is_blocked(session: AsyncSession) -> None:
    user = await _make_user(session, 1)
    settings = _make_settings()
    service = ReferralService(session, settings)

    referral = await service.register_referral(user, user)

    assert referral is None


async def test_duplicate_referral_registration_is_blocked(session: AsyncSession) -> None:
    referrer = await _make_user(session, 1)
    new_user = await _make_user(session, 2)
    settings = _make_settings()
    service = ReferralService(session, settings)

    first = await service.register_referral(referrer, new_user)
    assert first is not None

    second = await service.register_referral(referrer, new_user)
    assert second is None


async def test_valid_referral_grants_bonus_days(session: AsyncSession) -> None:
    referrer = await _make_user(session, 1)
    new_user = await _make_user(session, 2)
    settings = _make_settings(REFERRAL_REWARD_DAYS=5)
    service = ReferralService(session, settings)

    referral = await service.register_referral(referrer, new_user)
    granted = await service.grant_signup_reward_if_eligible(referral)

    assert granted is True

    stats = await service.get_stats(referrer.id)
    assert stats["total_referrals"] == 1
    assert stats["rewarded_days"] == 5


async def test_zero_reward_days_grants_nothing(session: AsyncSession) -> None:
    referrer = await _make_user(session, 1)
    new_user = await _make_user(session, 2)
    settings = _make_settings(REFERRAL_REWARD_DAYS=0)
    service = ReferralService(session, settings)

    referral = await service.register_referral(referrer, new_user)
    granted = await service.grant_signup_reward_if_eligible(referral)

    assert granted is False
