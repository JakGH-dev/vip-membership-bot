from __future__ import annotations

from datetime import timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.subscription import SubscriptionStatus
from app.database.repositories.plan_repo import PlanRepository
from app.database.repositories.user_repo import UserRepository
from app.services.subscription_service import SubscriptionService
from app.utils.datetime_utils import utcnow
from app.utils.codes import generate_referral_code


async def _make_user(session: AsyncSession, telegram_id: int = 1):
    user_repo = UserRepository(session)
    return await user_repo.create(
        telegram_id=telegram_id,
        username="tester",
        first_name="Test",
        last_name=None,
        language_code="en",
        referral_code=generate_referral_code(),
    )


async def _make_plan(session: AsyncSession, duration_days: int = 30, price: float = 9.99):
    plan_repo = PlanRepository(session)
    return await plan_repo.create(
        name=f"VIP {duration_days} Days",
        description="Test plan",
        price=price,
        currency="USD",
        duration_days=duration_days,
    )


async def test_grant_subscription_creates_new_when_none_exists(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session, duration_days=30)
    service = SubscriptionService(session)

    subscription = await service.grant_subscription(user.id, plan, payment_id=None)

    assert subscription.status == SubscriptionStatus.ACTIVE
    assert (subscription.expires_at - subscription.starts_at).days == 30


async def test_grant_subscription_stacks_remaining_days(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan_10 = await _make_plan(session, duration_days=10)
    plan_30 = await _make_plan(session, duration_days=30)
    service = SubscriptionService(session)

    first = await service.grant_subscription(user.id, plan_10, payment_id=None)
    original_expiry = first.expires_at

    second = await service.grant_subscription(user.id, plan_30, payment_id=None)

    # Renewing before expiry should ADD the new duration on top of the
    # remaining time, not overwrite it: 10 remaining + 30 new = 40 days.
    assert second.id == first.id
    assert second.expires_at == original_expiry + timedelta(days=30)


async def test_expire_due_subscriptions_marks_expired(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session, duration_days=1)
    service = SubscriptionService(session)

    subscription = await service.grant_subscription(user.id, plan, payment_id=None)
    # Force it into the past to simulate elapsed time.
    subscription.expires_at = utcnow() - timedelta(minutes=5)
    await session.flush()

    expired = await service.expire_due_subscriptions()

    assert len(expired) == 1
    assert expired[0].status == SubscriptionStatus.EXPIRED


async def test_grant_bonus_days_extends_active_subscription(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session, duration_days=10)
    service = SubscriptionService(session)

    subscription = await service.grant_subscription(user.id, plan, payment_id=None)
    original_expiry = subscription.expires_at

    updated = await service.grant_bonus_days(user.id, 5)

    assert updated.expires_at == original_expiry + timedelta(days=5)


async def test_grant_bonus_days_without_subscription_uses_fallback_plan(
    session: AsyncSession,
) -> None:
    user = await _make_user(session)
    await _make_plan(session, duration_days=7, price=5.0)
    service = SubscriptionService(session)

    subscription = await service.grant_bonus_days(user.id, 3)

    assert subscription.status == SubscriptionStatus.ACTIVE
    assert (subscription.expires_at - subscription.starts_at).days == 3


async def test_suspend_and_unsuspend(session: AsyncSession) -> None:
    admin = await _make_user(session, telegram_id=999)
    user = await _make_user(session, telegram_id=2)
    plan = await _make_plan(session)
    service = SubscriptionService(session)

    subscription = await service.grant_subscription(user.id, plan, payment_id=None)

    suspended = await service.suspend(subscription, admin.id)
    assert suspended.status == SubscriptionStatus.SUSPENDED

    unsuspended = await service.unsuspend(subscription, admin.id)
    assert unsuspended.status == SubscriptionStatus.ACTIVE
