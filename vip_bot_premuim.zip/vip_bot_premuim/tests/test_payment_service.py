from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import Settings
from app.database.models.payment import PaymentStatus
from app.database.repositories.payment_repo import DuplicatePaymentError
from app.database.repositories.plan_repo import PlanRepository
from app.database.repositories.user_repo import UserRepository
from app.services.payment_providers.base import InvoiceRequest, PaymentProvider
from app.services.payment_service import PaymentService, PaymentValidationError
from app.utils.codes import generate_referral_code


class FakePaymentProvider(PaymentProvider):
    name = "fake"

    def __init__(self) -> None:
        self.sent_invoices: list[InvoiceRequest] = []

    async def send_invoice(self, bot, request: InvoiceRequest) -> None:
        self.sent_invoices.append(request)

    def extract_provider_payment_id(self, update_payload: dict) -> str:
        return update_payload["charge_id"]


def _make_settings(**overrides) -> Settings:
    defaults = dict(
        BOT_TOKEN="123:ABC",
        ADMIN_IDS="1",
        VIP_CHANNEL_ID=-100123,
        TELEGRAM_PAYMENTS_PROVIDER_TOKEN="provider-token",
        DATABASE_URL="sqlite+aiosqlite:///:memory:",
        REDIS_URL="redis://localhost:6379/0",
    )
    defaults.update(overrides)
    return Settings(**defaults)


async def _make_user(session: AsyncSession, telegram_id: int = 1):
    user_repo = UserRepository(session)
    return await user_repo.create(
        telegram_id=telegram_id,
        username="tester",
        first_name="Test",
        last_name=None,
        language_code="en",
        referral_code=generate_referral_code(),
    )


async def _make_plan(session: AsyncSession):
    plan_repo = PlanRepository(session)
    return await plan_repo.create(
        name="VIP 30 Days",
        description="Test plan",
        price=9.99,
        currency="USD",
        duration_days=30,
    )


async def test_create_pending_payment_sends_invoice(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    provider = FakePaymentProvider()
    settings = _make_settings()
    service = PaymentService(session, settings, provider)

    payment = await service.create_pending_payment_and_invoice(
        bot=AsyncMock(), chat_id=user.telegram_id, user_id=user.id, plan=plan
    )

    assert payment.status == PaymentStatus.PENDING
    assert len(provider.sent_invoices) == 1
    assert provider.sent_invoices[0].amount == 9.99


async def test_confirm_payment_grants_subscription(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    provider = FakePaymentProvider()
    settings = _make_settings()
    service = PaymentService(session, settings, provider)

    payment = await service.create_pending_payment_and_invoice(
        bot=AsyncMock(), chat_id=user.telegram_id, user_id=user.id, plan=plan
    )

    confirmed = await service.confirm_payment_from_provider(
        invoice_payload=payment.invoice_payload,
        provider_update={"charge_id": "charge_abc123"},
    )

    assert confirmed.status == PaymentStatus.PAID

    active = await service.subscription_service.get_active_subscription(user.id)
    assert active is not None
    assert active.plan_id == plan.id


async def test_confirm_payment_is_idempotent(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    provider = FakePaymentProvider()
    settings = _make_settings()
    service = PaymentService(session, settings, provider)

    payment = await service.create_pending_payment_and_invoice(
        bot=AsyncMock(), chat_id=user.telegram_id, user_id=user.id, plan=plan
    )

    first = await service.confirm_payment_from_provider(
        invoice_payload=payment.invoice_payload,
        provider_update={"charge_id": "charge_dup"},
    )
    # Calling confirm again with the same payload must be a safe no-op,
    # not grant a second subscription period.
    second = await service.confirm_payment_from_provider(
        invoice_payload=payment.invoice_payload,
        provider_update={"charge_id": "charge_dup"},
    )

    assert first.id == second.id
    assert first.status == PaymentStatus.PAID == second.status


async def test_duplicate_charge_id_on_different_payment_is_rejected(session: AsyncSession) -> None:
    user = await _make_user(session)
    plan = await _make_plan(session)
    provider = FakePaymentProvider()
    settings = _make_settings()
    service = PaymentService(session, settings, provider)

    payment_a = await service.create_pending_payment_and_invoice(
        bot=AsyncMock(), chat_id=user.telegram_id, user_id=user.id, plan=plan
    )
    payment_b = await service.create_pending_payment_and_invoice(
        bot=AsyncMock(), chat_id=user.telegram_id, user_id=user.id, plan=plan
    )

    await service.confirm_payment_from_provider(
        invoice_payload=payment_a.invoice_payload,
        provider_update={"charge_id": "shared_charge_id"},
    )

    with pytest.raises(DuplicatePaymentError):
        await service.confirm_payment_from_provider(
            invoice_payload=payment_b.invoice_payload,
            provider_update={"charge_id": "shared_charge_id"},
        )


async def test_confirm_payment_unknown_payload_raises(session: AsyncSession) -> None:
    provider = FakePaymentProvider()
    settings = _make_settings()
    service = PaymentService(session, settings, provider)

    with pytest.raises(PaymentValidationError):
        await service.confirm_payment_from_provider(
            invoice_payload="nonexistent_payload",
            provider_update={"charge_id": "whatever"},
        )
