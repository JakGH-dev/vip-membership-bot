from __future__ import annotations

from datetime import datetime, timezone

from app.utils.datetime_utils import add_days, as_utc, format_remaining


def test_add_days() -> None:
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    result = add_days(start, 30)
    assert result == datetime(2026, 1, 31, tzinfo=timezone.utc)


def test_as_utc_adds_timezone_if_missing() -> None:
    naive = datetime(2026, 1, 1, 12, 0, 0)
    result = as_utc(naive)
    assert result.tzinfo is not None
    assert result.utcoffset().total_seconds() == 0


def test_format_remaining_zero() -> None:
    assert format_remaining(0) == "0m"
    assert format_remaining(-5) == "0m"


def test_format_remaining_days_hours_minutes() -> None:
    seconds = (2 * 24 * 3600) + (3 * 3600) + (15 * 60)
    result = format_remaining(seconds)
    assert result == "2d 3h 15m"


def test_format_remaining_minutes_only() -> None:
    assert format_remaining(300) == "5m"
